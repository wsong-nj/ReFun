

from likely_CR_site_pairings_analyzer import OverapproximateCallReturnSitePairings
class sao(object):
    def __init__(self, path, pair):
        self.path = path
        self.pair = pair
        self.code = OverapproximateCallReturnSitePairings(asm_file='disassembly_result.txt').blocks
        self.stack = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]        
    def sap(self):
        start_index = self.path.index(self.pair[0])  
        end_index = self.path.index(self.pair[-1]) + 1  
        sub_path = self.path[start_index:end_index + 1]

        for block in sub_path[:-1]:
            for opcode_line in self.code[block]:
                if opcode_line[1] == "STOP":
                    pass
                                    
                elif opcode_line[1] == 'ADD':  # 0x01
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.append(0)
                               
                elif opcode_line[1] == 'MUL':  # 0x02
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.append(0)
                                
                elif opcode_line[1] == 'SUB':  # 0x03
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.append(0)
                              
                elif opcode_line[1] == 'DIV':  # 0x04
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.append(0)
                
                elif opcode_line[1] == 'SDIV':  # 0x05
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.append(0)
                                   
                elif opcode_line[1] == 'MOD':  # 0x06
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.append(0)
                                
                elif opcode_line[1] == 'SMOD':  # 0x07
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.append(0)
                              
                elif opcode_line[1] == 'ADDMOD':  # 0x08
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.append(0)
                    
                elif opcode_line[1] == 'MULMOD':  # 0x09
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.append(0)
                          
                elif opcode_line[1] == 'EXP':  # 0x0a
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.append(0)
                    
                elif opcode_line[1] == 'SIGNEXTEND':  # 0x0b
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.append(0)
                   
                elif opcode_line[1] == 'LT':  # 0x10
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.append(0)
                   
                elif opcode_line[1] == 'GT':  # 0x11
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.append(0)
                   
                elif opcode_line[1] == 'SLT':  # 0x12
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.append(0)
                    
                elif opcode_line[1] == 'SGT':  # 0x13
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.append(0)
                    
                elif opcode_line[1] == 'EQ':  # 0x14
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.append(0)           
        
                elif opcode_line[1] == 'ISZERO':  # 0x15
                    self.stack.pop()
                    self.stack.append(0)           
        
                elif opcode_line[1] == 'AND':  # 0x16
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.append(0)
                   
                elif opcode_line[1] == 'OR':  # 0x17
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.append(0)            
        
                elif opcode_line[1] == 'XOR':  # 0x18
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.append(0)
                   
                elif opcode_line[1] == 'NOT':  # 0x19
                    self.stack.pop()
                    self.stack.append(0)
                    
                elif opcode_line[1] == 'BYTE':  # 0x1a
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.append(0)
                   
                elif opcode_line[1] == 'SHL':   #0x1b
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.append(0)
                    
                elif opcode_line[1] == 'SHR':   #0x1c
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.append(0)
                    
                elif opcode_line[1] == 'SAR':   #0x1d
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.append(0)
        
                elif opcode_line[1] == 'SHA3':  # 0x20
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.append(0)            
        
                elif opcode_line[1] == 'ADDRESS':  # 0x30
                    self.stack.append(0)           
        
                elif opcode_line[1] == 'BALANCE':  # 0x31
                    self.stack.pop()
                    self.stack.append(0)            
        
                elif opcode_line[1] == 'ORIGIN':  # 0x32
                    self.stack.append(0)
                    
                elif opcode_line[1] == 'CALLER':  # 0x33
                    self.stack.append(0)
                  
                elif opcode_line[1] == 'CALLVALUE':  # 0x34
                    self.stack.append(0)
                    
                elif opcode_line[1] == 'CALLDATALOAD':  # 0x35
                    self.stack.pop()
                    self.stack.append(0)
                    
                elif opcode_line[1] == 'CALLDATASIZE':  # 0x36
                    self.stack.append(0)
                    
                elif opcode_line[1] == 'CALLDATACOPY':  # 0x37
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.pop()
                    
                elif opcode_line[1] == 'CODESIZE':  # 0x38
                    self.stack.append(0)            
        
                elif opcode_line[1] == 'CODECOPY':  # 0x39
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.pop()
        
                elif opcode_line[1] == 'GASPRICE':  # 0x3a
                    self.stack.append(0) 
                    
                elif opcode_line[1] == 'EXTCODESIZE':  # 0x3b
                    self.stack.pop()
                    self.stack.append(0)
            
                elif opcode_line[1] == 'EXTCODECOPY':  # 0x3c
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.pop()
        
                elif opcode_line[1] == 'RETURNDATASIZE':  # 0x3d
                    self.stack.append(0)
        
                elif opcode_line[1] == 'RETURNDATACOPY':  # 0x3e
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.pop()
        
                elif opcode_line[1] == 'EXTCODEHASH':  # 0x3f
                    self.stack.pop()
                    self.stack.append(0)
        
                elif opcode_line[1] == 'BLOCKHASH':  # 0x40
                    self.stack.pop()
                    self.stack.append(0)
        
                elif opcode_line[1] == 'COINBASE':  # 0x41
                    self.stack.append(0)
                    
                elif opcode_line[1] == 'TIMESTAMP':  # 0x42
                    self.stack.append("timestamp")
                    
                elif opcode_line[1] == 'NUMBER':  # 0x43
                    self.stack.append("number")
                    
                elif opcode_line[1] == 'DIFFICULTY':  # 0x44
                    self.stack.append("diffiuclty")
                    
                elif opcode_line[1] == 'GASLIMIT':  # 0x45
                    self.stack.append("gaslimit")
                              
                elif opcode_line[1] == 'CHAINID':  # 0x46
                    self.stack.append("chainid")
                             
                elif opcode_line[1] == 'SELFBALANCE':  # 0x47
                    self.stack.append("selfbalance")   
        
                elif opcode_line[1] == 'BASEFEE':  # 0x48
                    self.stack.append("basefee")
        
                elif opcode_line[1] == 'POP':  # 0x50
                    self.stack.pop()
                   
                elif opcode_line[1] == 'MLOAD':  # 0x51
                    self.stack.pop()
                    self.stack.append(0)
        
                elif opcode_line[1] == 'MSTORE':# 0x52       
                    self.stack.pop()
                    self.stack.pop()
        
                elif opcode_line[1] == 'MSTORE8':# 0x53
                    self.stack.pop()
                    self.stack.pop()
        
                elif opcode_line[1] == 'SLOAD':  # 0x54
                    self.stack.pop()
                    self.stack.append(0)
        
                elif opcode_line[1] == 'SSTORE':  # 0x55
                    self.stack.pop()
                    self.stack.pop()
        
                elif opcode_line[1] == 'JUMP':  # 0x56
                    self.stack.pop()
                    
                elif opcode_line[1] == 'REQUIRE':
                    self.stack.pop()
                    
                elif opcode_line[1] == 'ASSERT':
                    self.stack.pop()
                                
                elif opcode_line[1] == 'JUMPI':  # 0x57
                    self.stack.pop()
                    self.stack.pop()
        
                elif opcode_line[1] == 'PC':  # 0x58
                    self.stack.append(0)
        
                elif opcode_line[1] == 'MSIZE':  # 0x59
                    self.stack.append(0)
        
                elif opcode_line[1] == 'GAS':  # 0x5a
                    self.stack.append(0)
        
                elif opcode_line[1] == 'JUMPDEST':  # 0x5b
                    pass


                elif opcode_line[1] == 'TLOAD':  # 0x5c
                    pass 

                elif opcode_line[1] == 'TSTORE':  # 0x5D
                    self.stack.pop()
                    self.stack.pop()

                elif opcode_line[1] == 'MCOPY':  # 0x5E
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.pop()


                elif opcode_line[1] == 'PUSH0':  # 0x5f
                    self.stack.append(f"{opcode_line[-1]}_pushed_in_{block}")                

                elif opcode_line[1] == 'PUSH1':  # 0x60
                    self.stack.append(f"{opcode_line[-1]}_pushed_in_{block}")
        
                elif opcode_line[1] == 'PUSH2':  # 0x61
                    self.stack.append(f"{opcode_line[-1]}_pushed_in_{block}")
        
                elif opcode_line[1] == 'PUSH3':  # 0x62
                    self.stack.append(f"{opcode_line[-1]}_pushed_in_{block}")
        
                elif opcode_line[1] == 'PUSH4':  # 0x63
                    self.stack.append(f"{opcode_line[-1]}_pushed_in_{block}")
        
                elif opcode_line[1] == 'PUSH5':  # 0x64
                    self.stack.append(f"{opcode_line[-1]}_pushed_in_{block}")
        
                elif opcode_line[1] == 'PUSH6':  # 0x65
                    self.stack.append(f"{opcode_line[-1]}_pushed_in_{block}")
        
                elif opcode_line[1] == 'PUSH7':  # 0x66
                    self.stack.append(f"{opcode_line[-1]}_pushed_in_{block}")
        
                elif opcode_line[1] == 'PUSH8':  # 0x67
                    self.stack.append(f"{opcode_line[-1]}_pushed_in_{block}")
        
                elif opcode_line[1] == 'PUSH9':  # 0x68
                    self.stack.append(f"{opcode_line[-1]}_pushed_in_{block}")
        
                elif opcode_line[1] == 'PUSH10':  # 0x69
                    self.stack.append(f"{opcode_line[-1]}_pushed_in_{block}")
        
                elif opcode_line[1] == 'PUSH11':  # 0x6a
                    self.stack.append(f"{opcode_line[-1]}_pushed_in_{block}")
        
                elif opcode_line[1] == 'PUSH12':  # 0x6b
                    self.stack.append(f"{opcode_line[-1]}_pushed_in_{block}")
        
                elif opcode_line[1] == 'PUSH13':  # 0x6c
                    self.stack.append(f"{opcode_line[-1]}_pushed_in_{block}")
        
                elif opcode_line[1] == 'PUSH14':  # 0x6d
                    self.stack.append(f"{opcode_line[-1]}_pushed_in_{block}")
                   
                elif opcode_line[1] == 'PUSH15':  # 0x6e
                    self.stack.append(f"{opcode_line[-1]}_pushed_in_{block}")
        
                elif opcode_line[1] == 'PUSH16':  # 0x6f
                    self.stack.append(f"{opcode_line[-1]}_pushed_in_{block}")
        
                elif opcode_line[1] == 'PUSH17':  # 0x70
                    self.stack.append(f"{opcode_line[-1]}_pushed_in_{block}")
        
                elif opcode_line[1] == 'PUSH18':  # 0x71
                    self.stack.append(f"{opcode_line[-1]}_pushed_in_{block}")
        
                elif opcode_line[1] == 'PUSH19':  # 0x72
                    self.stack.append(f"{opcode_line[-1]}_pushed_in_{block}")
        
                elif opcode_line[1] == 'PUSH20':  # 0x73
                    self.stack.append(f"{opcode_line[-1]}_pushed_in_{block}")
        
                elif opcode_line[1] == 'PUSH21':  # 0x74
                    self.stack.append(f"{opcode_line[-1]}_pushed_in_{block}")
        
                elif opcode_line[1] == 'PUSH22':  # 0x75
                    self.stack.append(f"{opcode_line[-1]}_pushed_in_{block}")
        
                elif opcode_line[1] == 'PUSH23':  # 0x76
                    self.stack.append(f"{opcode_line[1][-1]}_pushed_in_{block}")
        
                elif opcode_line[1] == 'PUSH24':  # 0x77
                    self.stack.append(f"{opcode_line[-1]}_pushed_in_{block}")
        
                elif opcode_line[1] == 'PUSH25':  # 0x78
                    self.stack.append(f"{opcode_line[-1]}_pushed_in_{block}")
        
                elif opcode_line[1] == 'PUSH26':  # 0x79
                    self.stack.append(f"{opcode_line[-1]}_pushed_in_{block}")
        
                elif opcode_line[1] == 'PUSH27':  # 0x7a
                    self.stack.append(f"{opcode_line[-1]}_pushed_in_{block}")
        
                elif opcode_line[1] == 'PUSH28':  # 0x7b
                    self.stack.append(f"{opcode_line[-1]}_pushed_in_{block}")
        
                elif opcode_line[1] == 'PUSH29':  # 0x7c
                    self.stack.append(f"{opcode_line[-1]}_pushed_in_{block}")
        
                elif opcode_line[1] == 'PUSH30':  # 0x7d
                    self.stack.append(f"{opcode_line[-1]}_pushed_in_{block}")
        
                elif opcode_line[1] == 'PUSH31':  # 0x7e
                    self.stack.append(f"{opcode_line[-1]}_pushed_in_{block}")
        
                elif opcode_line[1] == 'PUSH32':  # 0x7f
                    self.stack.append(f"{opcode_line[-1]}_pushed_in_{block}")
        
                elif opcode_line[1] == 'DUP1':  # 0x80
                    self.stack.append(self.stack[-1])
        
                elif opcode_line[1] == 'DUP2':  # 0x81
                    self.stack.append(self.stack[-2])
        
                elif opcode_line[1] == 'DUP3':  # 0x82
                    self.stack.append(self.stack[-3])
                    
                elif opcode_line[1] == 'DUP4':  # 0x83
                    self.stack.append(self.stack[-4])
                    
                elif opcode_line[1] == 'DUP5':  # 0x84
                    self.stack.append(self.stack[-5])
                    
                elif opcode_line[1] == 'DUP6':  # 0x85
                    self.stack.append(self.stack[-6])
                    
                elif opcode_line[1] == 'DUP7':  # 0x86
                    self.stack.append(self.stack[-7])
                    
                elif opcode_line[1] == 'DUP8':  # 0x87
                    self.stack.append(self.stack[-8])
                    
                elif opcode_line[1] == 'DUP9':  # 0x88
                    self.stack.append(self.stack[-9])
                    
                elif opcode_line[1] == 'DUP10':  # 0x89
                    self.stack.append(self.stack[-10])
                    
                elif opcode_line[1] == 'DUP11':  # 0x8a
                    self.stack.append(self.stack[-11])
                    
                elif opcode_line[1] == 'DUP12':  # 0x8b
                    self.stack.append(self.stack[-12])
                    
                elif opcode_line[1] == 'DUP13':  # 0x8c
                    self.stack.append(self.stack[-13])
                    
                elif opcode_line[1] == 'DUP14':  # 0x8d
                    self.stack.append(self.stack[-14])
                    
                elif opcode_line[1] == 'DUP15':  # 0x8e
                    self.stack.append(self.stack[-15])
                    
                elif opcode_line[1] == 'DUP16':  # 0x8f
                    self.stack.append(self.stack[-16])
                    
                elif opcode_line[1] == 'SWAP1':  # 0x90
                    val1 = self.stack.pop()
                    val2 = self.stack.pop()
                    self.stack.append(val1)
                    self.stack.append(val2)
                    
                elif opcode_line[1] == 'SWAP2':  # 0x91
                    val1 = self.stack.pop()
                    val2 = self.stack.pop()
                    val3 = self.stack.pop()
                    self.stack.append(val1)
                    self.stack.append(val2)
                    self.stack.append(val3)
                                          
                elif opcode_line[1] == 'SWAP3':  # 0x92
                    val1 = self.stack.pop()
                    val2 = self.stack.pop()
                    val3 = self.stack.pop()
                    val4 = self.stack.pop()
                    self.stack.append(val1)
                    self.stack.append(val3)
                    self.stack.append(val2)
                    self.stack.append(val4)
                    
                elif opcode_line[1] == 'SWAP4':  # 0x93
                    val1 = self.stack.pop()
                    val2 = self.stack.pop()
                    val3 = self.stack.pop()
                    val4 = self.stack.pop()
                    val5 = self.stack.pop()
                    self.stack.append(val1)
                    self.stack.append(val4)
                    self.stack.append(val3)
                    self.stack.append(val2)
                    self.stack.append(val5)
                    
                elif opcode_line[1] == 'SWAP5':  # 0x94
                    val1 = self.stack.pop()
                    val2 = self.stack.pop()
                    val3 = self.stack.pop()
                    val4 = self.stack.pop()
                    val5 = self.stack.pop()
                    val6 = self.stack.pop()
                    self.stack.append(val1)
                    self.stack.append(val5)
                    self.stack.append(val4)
                    self.stack.append(val3)
                    self.stack.append(val2)
                    self.stack.append(val6)
                    
                elif opcode_line[1] == 'SWAP6':  # 0x95
                    val1 = self.stack.pop()
                    val2 = self.stack.pop()
                    val3 = self.stack.pop()
                    val4 = self.stack.pop()
                    val5 = self.stack.pop()
                    val6 = self.stack.pop()
                    val7 = self.stack.pop()
                    self.stack.append(val1)
                    self.stack.append(val6)
                    self.stack.append(val5)
                    self.stack.append(val4)
                    self.stack.append(val3)
                    self.stack.append(val2)
                    self.stack.append(val7)
                    
                elif opcode_line[1] == 'SWAP7':  # 0x96
                    val1 = self.stack.pop()
                    val2 = self.stack.pop()
                    val3 = self.stack.pop()
                    val4 = self.stack.pop()
                    val5 = self.stack.pop()
                    val6 = self.stack.pop()
                    val7 = self.stack.pop()
                    val8 = self.stack.pop()
                    self.stack.append(val1)
                    self.stack.append(val7)
                    self.stack.append(val6)
                    self.stack.append(val5)
                    self.stack.append(val4)
                    self.stack.append(val3)
                    self.stack.append(val2)
                    self.stack.append(val8)
                    
                elif opcode_line[1] == 'SWAP8':  # 0x97
                    val1 = self.stack.pop()
                    val2 = self.stack.pop()
                    val3 = self.stack.pop()
                    val4 = self.stack.pop()
                    val5 = self.stack.pop()
                    val6 = self.stack.pop()
                    val7 = self.stack.pop()
                    val8 = self.stack.pop()
                    val9 = self.stack.pop()
                    self.stack.append(val1)
                    self.stack.append(val8)
                    self.stack.append(val7)
                    self.stack.append(val6)
                    self.stack.append(val5)
                    self.stack.append(val4)
                    self.stack.append(val3)
                    self.stack.append(val2)
                    self.stack.append(val9)
                    
                elif opcode_line[1] == 'SWAP9':  # 0x98
                    val1 = self.stack.pop()
                    val2 = self.stack.pop()
                    val3 = self.stack.pop()
                    val4 = self.stack.pop()
                    val5 = self.stack.pop()
                    val6 = self.stack.pop()
                    val7 = self.stack.pop()
                    val8 = self.stack.pop()
                    val9 = self.stack.pop()
                    val10 = self.stack.pop()
                    self.stack.append(val1)
                    self.stack.append(val9)
                    self.stack.append(val8)
                    self.stack.append(val7)
                    self.stack.append(val6)
                    self.stack.append(val5)
                    self.stack.append(val4)
                    self.stack.append(val3)
                    self.stack.append(val2)
                    self.stack.append(val10)
                    
                elif opcode_line[1] == 'SWAP10':  # 0x99
                    val1 = self.stack.pop()
                    val2 = self.stack.pop()
                    val3 = self.stack.pop()
                    val4 = self.stack.pop()
                    val5 = self.stack.pop()
                    val6 = self.stack.pop()
                    val7 = self.stack.pop()
                    val8 = self.stack.pop()
                    val9 = self.stack.pop()
                    val10 = self.stack.pop()
                    val11 = self.stack.pop()
                    self.stack.append(val1)
                    self.stack.append(val10)
                    self.stack.append(val9)
                    self.stack.append(val8)
                    self.stack.append(val7)
                    self.stack.append(val6)
                    self.stack.append(val5)
                    self.stack.append(val4)
                    self.stack.append(val3)
                    self.stack.append(val2)
                    self.stack.append(val11)
                    
                elif opcode_line[1] == 'SWAP11':  # 0x9a
                    val1 = self.stack.pop()
                    val2 = self.stack.pop()
                    val3 = self.stack.pop()
                    val4 = self.stack.pop()
                    val5 = self.stack.pop()
                    val6 = self.stack.pop()
                    val7 = self.stack.pop()
                    val8 = self.stack.pop()
                    val9 = self.stack.pop()
                    val10 = self.stack.pop()
                    val11 = self.stack.pop()
                    val12 = self.stack.pop()
                    self.stack.append(val1)
                    self.stack.append(val11)
                    self.stack.append(val10)
                    self.stack.append(val9)
                    self.stack.append(val8)
                    self.stack.append(val7)
                    self.stack.append(val6)
                    self.stack.append(val5)
                    self.stack.append(val4)
                    self.stack.append(val3)
                    self.stack.append(val2)
                    self.stack.append(val12)
                                
                elif opcode_line[1] == 'SWAP12':  # 0x9b
                    val1 = self.stack.pop()
                    val2 = self.stack.pop()
                    val3 = self.stack.pop()
                    val4 = self.stack.pop()
                    val5 = self.stack.pop()
                    val6 = self.stack.pop()
                    val7 = self.stack.pop()
                    val8 = self.stack.pop()
                    val9 = self.stack.pop()
                    val10 = self.stack.pop()
                    val11 = self.stack.pop()
                    val12 = self.stack.pop()
                    val13 = self.stack.pop()
                    self.stack.append(val1)
                    self.stack.append(val12)
                    self.stack.append(val11)
                    self.stack.append(val10)
                    self.stack.append(val9)
                    self.stack.append(val8)
                    self.stack.append(val7)
                    self.stack.append(val6)
                    self.stack.append(val5)
                    self.stack.append(val4)
                    self.stack.append(val3)
                    self.stack.append(val2)
                    self.stack.append(val13)
                    
                elif opcode_line[1] == 'SWAP13':  # 0x9c
                    val1 = self.stack.pop()
                    val2 = self.stack.pop()
                    val3 = self.stack.pop()
                    val4 = self.stack.pop()
                    val5 = self.stack.pop()
                    val6 = self.stack.pop()
                    val7 = self.stack.pop()
                    val8 = self.stack.pop()
                    val9 = self.stack.pop()
                    val10 = self.stack.pop()
                    val11 = self.stack.pop()
                    val12 = self.stack.pop()
                    val13 = self.stack.pop()
                    val14 = self.stack.pop()
                    self.stack.append(val1)
                    self.stack.append(val13)
                    self.stack.append(val12)
                    self.stack.append(val11)
                    self.stack.append(val10)
                    self.stack.append(val9)
                    self.stack.append(val8)
                    self.stack.append(val7)
                    self.stack.append(val6)
                    self.stack.append(val5)
                    self.stack.append(val4)
                    self.stack.append(val3)
                    self.stack.append(val2)
                    self.stack.append(val14)
               
                elif opcode_line[1] == 'SWAP14':  # 0x9d
                    val1 = self.stack.pop()
                    val2 = self.stack.pop()
                    val3 = self.stack.pop()
                    val4 = self.stack.pop()
                    val5 = self.stack.pop()
                    val6 = self.stack.pop()
                    val7 = self.stack.pop()
                    val8 = self.stack.pop()
                    val9 = self.stack.pop()
                    val10 = self.stack.pop()
                    val11 = self.stack.pop()
                    val12 = self.stack.pop()
                    val13 = self.stack.pop()
                    val14 = self.stack.pop()
                    val15 = self.stack.pop()
                    self.stack.append(val1)
                    self.stack.append(val14)
                    self.stack.append(val13)
                    self.stack.append(val12)
                    self.stack.append(val11)
                    self.stack.append(val10)
                    self.stack.append(val9)
                    self.stack.append(val8)
                    self.stack.append(val7)
                    self.stack.append(val6)
                    self.stack.append(val5)
                    self.stack.append(val4)
                    self.stack.append(val3)
                    self.stack.append(val2)
                    self.stack.append(val15)             
        
                elif opcode_line[1] == 'SWAP15':  # 0x9e
                    val1 = self.stack.pop()
                    val2 = self.stack.pop()
                    val3 = self.stack.pop()
                    val4 = self.stack.pop()
                    val5 = self.stack.pop()
                    val6 = self.stack.pop()
                    val7 = self.stack.pop()
                    val8 = self.stack.pop()
                    val9 = self.stack.pop()
                    val10 = self.stack.pop()
                    val11 = self.stack.pop()
                    val12 = self.stack.pop()
                    val13 = self.stack.pop()
                    val14 = self.stack.pop()
                    val15 = self.stack.pop()
                    val16 = self.stack.pop()
                    self.stack.append(val1)
                    self.stack.append(val15)
                    self.stack.append(val14)
                    self.stack.append(val13)
                    self.stack.append(val12)
                    self.stack.append(val11)
                    self.stack.append(val10)
                    self.stack.append(val9)
                    self.stack.append(val8)
                    self.stack.append(val7)
                    self.stack.append(val6)
                    self.stack.append(val5)
                    self.stack.append(val4)
                    self.stack.append(val3)
                    self.stack.append(val2)
                    self.stack.append(val16)              
        
                elif opcode_line[1] == 'SWAP16':  # 0x9f
                    val1 = self.stack.pop()
                    val2 = self.stack.pop()
                    val3 = self.stack.pop()
                    val4 = self.stack.pop()
                    val5 = self.stack.pop()
                    val6 = self.stack.pop()
                    val7 = self.stack.pop()
                    val8 = self.stack.pop()
                    val9 = self.stack.pop()
                    val10 = self.stack.pop()
                    val11 = self.stack.pop()
                    val12 = self.stack.pop()
                    val13 = self.stack.pop()
                    val14 = self.stack.pop()
                    val15 = self.stack.pop()
                    val16 = self.stack.pop()
                    val17 = self.stack.pop()
                    self.stack.append(val1)
                    self.stack.append(val16)
                    self.stack.append(val15)
                    self.stack.append(val14)
                    self.stack.append(val13)
                    self.stack.append(val12)
                    self.stack.append(val11)
                    self.stack.append(val10)
                    self.stack.append(val9)
                    self.stack.append(val8)
                    self.stack.append(val7)
                    self.stack.append(val6)
                    self.stack.append(val5)
                    self.stack.append(val4)
                    self.stack.append(val3)
                    self.stack.append(val2)
                    self.stack.append(val17)             
        
                elif opcode_line[1] == 'LOG0':  # 0xa0
                    self.stack.pop()
                    self.stack.pop()
        
                elif opcode_line[1] == 'LOG1':  # 0xa1
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.pop()
        
                elif opcode_line[1] == 'LOG2':  # 0xa2
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.pop()
        
                elif opcode_line[1] == 'LOG3':  # 0xa3
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.pop()
        
                elif opcode_line[1] == 'LOG4':  # 0xa4
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.pop()
        
                elif opcode_line[1] == 'CREATE':  # 0xf0
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.append(0)
        
                elif opcode_line[1] == 'CALL':    # 0xf1
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.append(0)            
        
                elif opcode_line[1] == 'CALLCODE':  # 0xf2
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.append(0)
        
                elif opcode_line[1] == 'RETURN':  # 0xf3
                    self.stack.pop()
                    self.stack.pop()
        
                elif opcode_line[1] == 'DELEGATECALL':        # 0xf4
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.append(0)
                        
                elif opcode_line[1] == 'CREATE2':  # 0xf5
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.append(0)    
              
                elif opcode_line[1] == 'STATICCALL':  # 0xfa
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.pop()
                    self.stack.append(0)                        
                        
                elif opcode_line[1] == 'REVERT':  # 0xfd
                    self.stack.pop()
                    self.stack.pop()                 
                        
                elif opcode_line[1] == 'INVALID':  # 0xfe
                    pass
        
                elif opcode_line[1] == 'SELFDESTRUCT':  # 0xff
                    self.stack.pop()
        
                elif opcode_line[1] == '95':  # accident
                    pass
                    
                else:
                    print(opcode_line[1])
                    #print(self.stack)
                    #print(self.code[block])
                    
                    raise Exception("unknown opcode")
        return self.stack
    


    def saq(self):
        stack_after_moving = self.sap()
        #print(stack_after_moving)
        last_block = self.path[self.path.index(self.pair[-1]) + 1]  
        #print(last_block)


        for opcode_line in self.code[last_block]:
            if opcode_line[1] == "STOP":
                pass
                                    
            elif opcode_line[1] == 'ADD':  # 0x01
                add1 = stack_after_moving.pop()
                add2 = stack_after_moving.pop()
                stack_after_moving.append(0)
                if f'pushed_in_{self.pair[0]}' in str(add1) or f'pushed_in_{self.pair[0]}' in str(add2):
                    return 1
                           
            elif opcode_line[1] == 'MUL':  # 0x02
                mul1 = stack_after_moving.pop()
                mul2 = stack_after_moving.pop()
                stack_after_moving.append(0)
                if f'pushed_in_{self.pair[0]}' in str(mul1) or f'pushed_in_{self.pair[0]}' in str(mul2):
                    return 1
                            
            elif opcode_line[1] == 'SUB':  # 0x03
                sub1 = stack_after_moving.pop()
                sub2 = stack_after_moving.pop()
                stack_after_moving.append(0)
                if f'pushed_in_{self.pair[0]}' in str(sub1) or f'pushed_in_{self.pair[0]}' in str(sub2):
                    return 1
                          
            elif opcode_line[1] == 'DIV':  # 0x04
                div1 = stack_after_moving.pop()
                div2 = stack_after_moving.pop()
                stack_after_moving.append(0)
                if f'pushed_in_{self.pair[0]}' in str(div1) or f'pushed_in_{self.pair[0]}' in str(div2):
                    return 1
            
            elif opcode_line[1] == 'SDIV':  # 0x05
                sdiv1 = stack_after_moving.pop()
                sdiv2 = stack_after_moving.pop()
                stack_after_moving.append(0)
                if f'pushed_in_{self.pair[0]}' in str(sdiv1) or f'pushed_in_{self.pair[0]}' in str(sdiv2):
                    return 1
                               
            elif opcode_line[1] == 'MOD':  # 0x06
                mod1 = stack_after_moving.pop()
                mod2 = stack_after_moving.pop()
                stack_after_moving.append(0)
                if f'pushed_in_{self.pair[0]}' in str(mod1) or f'pushed_in_{self.pair[0]}' in str(mod2):
                    return 1
                            
            elif opcode_line[1] == 'SMOD':  # 0x07
                smod1 = stack_after_moving.pop()
                smod2 = stack_after_moving.pop()
                stack_after_moving.append(0)
                if f'pushed_in_{self.pair[0]}' in str(smod1) or f'pushed_in_{self.pair[0]}' in str(smod2):
                    return 1
                          
            elif opcode_line[1] == 'ADDMOD':  # 0x08
                addmod1 = stack_after_moving.pop()
                addmod2 = stack_after_moving.pop()
                addmod3 = stack_after_moving.pop()
                stack_after_moving.append(0)
                if f'pushed_in_{self.pair[0]}' in str(addmod1) or f'pushed_in_{self.pair[0]}' in str(addmod2) or f'pushed_in_{self.pair[0]}' in str(addmod3):
                    return 1
                
            elif opcode_line[1] == 'MULMOD':  # 0x09
                mulmod1 = stack_after_moving.pop()
                mulmod2 = stack_after_moving.pop()
                mulmod3 = stack_after_moving.pop()
                stack_after_moving.append(0)
                if f'pushed_in_{self.pair[0]}' in str(mulmod1) or f'pushed_in_{self.pair[0]}' in str(mulmod2) or f'pushed_in_{self.pair[0]}' in str(mulmod3):
                    return 1
                      
            elif opcode_line[1] == 'EXP':  # 0x0a
                exp1 = stack_after_moving.pop()
                exp2 = stack_after_moving.pop()
                stack_after_moving.append(0)
                if f'pushed_in_{self.pair[0]}' in str(exp1) or f'pushed_in_{self.pair[0]}' in str(exp2):
                    return 1
                
            elif opcode_line[1] == 'SIGNEXTEND':  # 0x0b
                sig1 = stack_after_moving.pop()
                sig2 = stack_after_moving.pop()
                stack_after_moving.append(0)
                if f'pushed_in_{self.pair[0]}' in str(sig1) or f'pushed_in_{self.pair[0]}' in str(sig2):
                    return 1
               
            elif opcode_line[1] == 'LT':  # 0x10
                lt1 = stack_after_moving.pop()
                lt2 = stack_after_moving.pop()
                #print(lt1)
                #print(lt2)
                stack_after_moving.append(0)
                if f'pushed_in_{self.pair[0]}' in str(lt1) or f'pushed_in_{self.pair[0]}' in str(lt2):
                    #print("here")
                    return 1
               
            elif opcode_line[1] == 'GT':  # 0x11
                gt1 = stack_after_moving.pop()
                gt2 = stack_after_moving.pop()
                stack_after_moving.append(0)
                if f'pushed_in_{self.pair[0]}' in str(gt1) or f'pushed_in_{self.pair[0]}' in str(gt2):
                    return 1
               
            elif opcode_line[1] == 'SLT':  # 0x12
                slt1 = stack_after_moving.pop()
                slt2 = stack_after_moving.pop()
                stack_after_moving.append(0)
                if f'pushed_in_{self.pair[0]}' in str(slt1) or f'pushed_in_{self.pair[0]}' in str(slt2):
                    return 1
                
            elif opcode_line[1] == 'SGT':  # 0x13
                sgt1 = stack_after_moving.pop()
                sgt2 = stack_after_moving.pop()
                stack_after_moving.append(0)
                if f'pushed_in_{self.pair[0]}' in str(sgt1) or f'pushed_in_{self.pair[0]}' in str(sgt2):
                    return 1
                
            elif opcode_line[1] == 'EQ':  # 0x14
                eq1 = stack_after_moving.pop()
                eq2 = stack_after_moving.pop()
                stack_after_moving.append(0)
                if f'pushed_in_{self.pair[0]}' in str(eq1) or f'pushed_in_{self.pair[0]}' in str(eq2):
                    return 1          
    
            elif opcode_line[1] == 'ISZERO':  # 0x15
                iszero1 = stack_after_moving.pop()
                stack_after_moving.append(0)           
                if f'pushed_in_{self.pair[0]}' in str(iszero1):
                    return 1  

    
            elif opcode_line[1] == 'AND':  # 0x16
                and1 = stack_after_moving.pop()
                and2 = stack_after_moving.pop()
                stack_after_moving.append(0)
                if f'pushed_in_{self.pair[0]}' in str(and1) or f'pushed_in_{self.pair[0]}' in str(and2):
                    return 1 
               
            elif opcode_line[1] == 'OR':  # 0x17
                or1 = stack_after_moving.pop()
                or2 = stack_after_moving.pop()
                stack_after_moving.append(0)
                if f'pushed_in_{self.pair[0]}' in str(or1) or f'pushed_in_{self.pair[0]}' in str(or2):
                    return 1            
    
            elif opcode_line[1] == 'XOR':  # 0x18
                xor1 = stack_after_moving.pop()
                xor2 = stack_after_moving.pop()
                stack_after_moving.append(0)
                if f'pushed_in_{self.pair[0]}' in str(xor1) or f'pushed_in_{self.pair[0]}' in str(xor2):
                    return 1 
               
            elif opcode_line[1] == 'NOT':  # 0x19
                not1 = stack_after_moving.pop()
                stack_after_moving.append(0)           
                if f'pushed_in_{self.pair[0]}' in str(not1):
                    return 1  
                
            elif opcode_line[1] == 'BYTE':  # 0x1a
                byte1 = stack_after_moving.pop()
                byte2 = stack_after_moving.pop()
                stack_after_moving.append(0)
                if f'pushed_in_{self.pair[0]}' in str(byte1) or f'pushed_in_{self.pair[0]}' in str(byte2):
                    return 1 
               
            elif opcode_line[1] == 'SHL':   #0x1b
                shl1 = stack_after_moving.pop()
                shl2 = stack_after_moving.pop()
                stack_after_moving.append(0)
                if f'pushed_in_{self.pair[0]}' in str(shl1) or f'pushed_in_{self.pair[0]}' in str(shl2):
                    return 1 
                
            elif opcode_line[1] == 'SHR':   #0x1c
                shr1 = stack_after_moving.pop()
                shr2 = stack_after_moving.pop()
                stack_after_moving.append(0)
                if f'pushed_in_{self.pair[0]}' in str(shr1) or f'pushed_in_{self.pair[0]}' in str(shr2):
                    return 1 
                
            elif opcode_line[1] == 'SAR':   #0x1d
                sar1 = stack_after_moving.pop()
                sar2 = stack_after_moving.pop()
                stack_after_moving.append(0)
                if f'pushed_in_{self.pair[0]}' in str(sar1) or f'pushed_in_{self.pair[0]}' in str(sar2):
                    return 1 
    
            elif opcode_line[1] == 'SHA3':  # 0x20
                sha1 = stack_after_moving.pop()
                sha2 = stack_after_moving.pop()
                stack_after_moving.append(0)
                if f'pushed_in_{self.pair[0]}' in str(sha1) or f'pushed_in_{self.pair[0]}' in str(sha2):
                    return 1         


            elif opcode_line[1] == 'KECCAK256':  # 0x20
                keccak1 = stack_after_moving.pop()
                keccak2 = stack_after_moving.pop()
                stack_after_moving.append(0)
                if f'pushed_in_{self.pair[0]}' in str(keccak1) or f'pushed_in_{self.pair[0]}' in str(keccak2):
                    return 1  
    
            elif opcode_line[1] == 'ADDRESS':  # 0x30
                stack_after_moving.append(0)           
    
            elif opcode_line[1] == 'BALANCE':  # 0x31
                balance1 = stack_after_moving.pop()
                stack_after_moving.append(0)            
                if f'pushed_in_{self.pair[0]}' in str(balance1):
                    return 1 
    
            elif opcode_line[1] == 'ORIGIN':  # 0x32
                stack_after_moving.append(0)
                
            elif opcode_line[1] == 'CALLER':  # 0x33
                stack_after_moving.append(0)
              
            elif opcode_line[1] == 'CALLVALUE':  # 0x34
                stack_after_moving.append(0)
                
            elif opcode_line[1] == 'CALLDATALOAD':  # 0x35
                calldata1 = stack_after_moving.pop()
                stack_after_moving.append(0)            
                if f'pushed_in_{self.pair[0]}' in str(calldata1):
                    return 1 
                
            elif opcode_line[1] == 'CALLDATASIZE':  # 0x36
                stack_after_moving.append(0)
                
            elif opcode_line[1] == 'CALLDATACOPY':  # 0x37
                calldatacopy1 = stack_after_moving.pop()
                calldatacopy2 = stack_after_moving.pop()
                calldatacopy3 = stack_after_moving.pop()
                if f'pushed_in_{self.pair[0]}' in str(calldatacopy1) or f'pushed_in_{self.pair[0]}' in str(calldatacopy2) or f'pushed_in_{self.pair[0]}' in str(calldatacopy3):
                    return 1 
                
            elif opcode_line[1] == 'CODESIZE':  # 0x38
                stack_after_moving.append(0)            
    
            elif opcode_line[1] == 'CODECOPY':  # 0x39
                codecopy1 = stack_after_moving.pop()
                codecopy2 = stack_after_moving.pop()
                codecopy3 = stack_after_moving.pop()
                if f'pushed_in_{self.pair[0]}' in str(codecopy1) or f'pushed_in_{self.pair[0]}' in str(codecopy2) or f'pushed_in_{self.pair[0]}' in str(codecopy3):
                    return 1
    
            elif opcode_line[1] == 'GASPRICE':  # 0x3a
                stack_after_moving.append(0) 
                
            elif opcode_line[1] == 'EXTCODESIZE':  # 0x3b
                extcodesize1 = stack_after_moving.pop()
                stack_after_moving.append(0)
                if f'pushed_in_{self.pair[0]}' in str(extcodesize1):
                    return 1 
        
            elif opcode_line[1] == 'EXTCODECOPY':  # 0x3c
                extcodecopy1 = stack_after_moving.pop()
                extcodecopy2 = stack_after_moving.pop()
                extcodecopy3 = stack_after_moving.pop()
                extcodecopy4 = stack_after_moving.pop()
                if f'pushed_in_{self.pair[0]}' in str(extcodecopy1) or f'pushed_in_{self.pair[0]}' in str(extcodecopy2) or f'pushed_in_{self.pair[0]}' in str(extcodecopy3) or f'pushed_in_{self.pair[0]}' in str(extcodecopy4):
                    return 1
                
                
            elif opcode_line[1] == 'RETURNDATASIZE':  # 0x3d
                stack_after_moving.append(0)
    
            elif opcode_line[1] == 'RETURNDATACOPY':  # 0x3e
                returndatacopy1 = stack_after_moving.pop()
                returndatacopy2 = stack_after_moving.pop()
                returndatacopy3 = stack_after_moving.pop()
                if f'pushed_in_{self.pair[0]}' in str(returndatacopy1) or f'pushed_in_{self.pair[0]}' in str(returndatacopy2) or f'pushed_in_{self.pair[0]}' in str(returndatacopy3):
                    return 1                
                
    
            elif opcode_line[1] == 'EXTCODEHASH':  # 0x3f
                extcodehash1 = stack_after_moving.pop()
                stack_after_moving.append(0)
                if f'pushed_in_{self.pair[0]}' in str(extcodehash1):
                    return 1
    
            elif opcode_line[1] == 'BLOCKHASH':  # 0x40
                blockhash1 = stack_after_moving.pop()
                stack_after_moving.append(0)
                if f'pushed_in_{self.pair[0]}' in str(blockhash1):
                    return 1
                
            elif opcode_line[1] == 'COINBASE':  # 0x41
                stack_after_moving.append(0)
                
            elif opcode_line[1] == 'TIMESTAMP':  # 0x42
                stack_after_moving.append(0)
                
            elif opcode_line[1] == 'NUMBER':  # 0x43
                stack_after_moving.append(0)
                
            elif opcode_line[1] == 'DIFFICULTY':  # 0x44
                stack_after_moving.append(0)
                
            elif opcode_line[1] == 'GASLIMIT':  # 0x45
                stack_after_moving.append(0)
                          
            elif opcode_line[1] == 'CHAINID':  # 0x46
                stack_after_moving.append(0)
                         
            elif opcode_line[1] == 'SELFBALANCE':  # 0x47
                stack_after_moving.append(0)   
    
            elif opcode_line[1] == 'BASEFEE':  # 0x48
                stack_after_moving.append(0)
    
            elif opcode_line[1] == 'POP':  # 0x50
                pop1 = stack_after_moving.pop()
                #print(pop1)
                if f'pushed_in_{self.pair[0]}' in str(pop1):
                    return 1
               
            elif opcode_line[1] == 'MLOAD':  # 0x51
                mload1 = stack_after_moving.pop()
                stack_after_moving.append(0)
                if f'pushed_in_{self.pair[0]}' in str(mload1):
                    return 1
                
                
            elif opcode_line[1] == 'MSTORE':# 0x52       
                mstore1 = stack_after_moving.pop()
                mstore2 = stack_after_moving.pop()
                if f'pushed_in_{self.pair[0]}' in str(mstore1) or f'pushed_in_{self.pair[0]}' in str(mstore2):
                    return 1
    
            elif opcode_line[1] == 'MSTORE8':# 0x53
                mstore81 = stack_after_moving.pop()
                mstore82 = stack_after_moving.pop()
                if f'pushed_in_{self.pair[0]}' in str(mstore81) or f'pushed_in_{self.pair[0]}' in str(mstore82):
                    return 1
    
            elif opcode_line[1] == 'SLOAD':  # 0x54
                sload1 = stack_after_moving.pop()
                stack_after_moving.append(0)
                if f'pushed_in_{self.pair[0]}' in str(sload1):
                    return 1
    
            elif opcode_line[1] == 'SSTORE':  # 0x55
                sstore1 = stack_after_moving.pop()
                sstore2 = stack_after_moving.pop()
                if f'pushed_in_{self.pair[0]}' in str(sstore1) or f'pushed_in_{self.pair[0]}' in str(sstore2):
                    return 1
    
            elif opcode_line[1] == 'JUMP':  # 0x56
                stack_after_moving.pop()
                
            elif opcode_line[1] == 'REQUIRE':
                stack_after_moving.pop()
                
            elif opcode_line[1] == 'ASSERT':
                stack_after_moving.pop()
                            
            elif opcode_line[1] == 'JUMPI':  # 0x57
                stack_after_moving.pop()
                stack_after_moving.pop()
    
            elif opcode_line[1] == 'PC':  # 0x58
                stack_after_moving.append(0)
    
            elif opcode_line[1] == 'MSIZE':  # 0x59
                stack_after_moving.append(0)
    
            elif opcode_line[1] == 'GAS':  # 0x5a
                stack_after_moving.append(0)
    
            elif opcode_line[1] == 'JUMPDEST':  # 0x5b
                pass


            elif opcode_line[1] == 'TLOAD':  # 0x5c
                pass 

            elif opcode_line[1] == 'TSTORE':  # 0x5D
                tstore1 = stack_after_moving.pop()
                tstore2 = stack_after_moving.pop()
                if f'pushed_in_{self.pair[0]}' in str(tstore1) or f'pushed_in_{self.pair[0]}' in str(tstore2):
                    return 1

            elif opcode_line[1] == 'MCOPY':  # 0x5E
                mcopy1 = stack_after_moving.pop()
                mcopy2 = stack_after_moving.pop()
                mcopy3 = stack_after_moving.pop()
                if f'pushed_in_{self.pair[0]}' in str(mcopy1) or f'pushed_in_{self.pair[0]}' in str(mcopy2) or f'pushed_in_{self.pair[0]}' in str(mcopy3):
                    return 1

            elif opcode_line[1] == 'PUSH0':  # 0x5f
                stack_after_moving.append(0)                

            elif opcode_line[1] == 'PUSH1':  # 0x60
                stack_after_moving.append(0)
    
            elif opcode_line[1] == 'PUSH2':  # 0x61
                stack_after_moving.append(0)
    
            elif opcode_line[1] == 'PUSH3':  # 0x62
                stack_after_moving.append(0)
    
            elif opcode_line[1] == 'PUSH4':  # 0x63
                stack_after_moving.append(0)
    
            elif opcode_line[1] == 'PUSH5':  # 0x64
                stack_after_moving.append(0)
    
            elif opcode_line[1] == 'PUSH6':  # 0x65
                stack_after_moving.append(0)
    
            elif opcode_line[1] == 'PUSH7':  # 0x66
                stack_after_moving.append(0)
    
            elif opcode_line[1] == 'PUSH8':  # 0x67
                stack_after_moving.append(0)
    
            elif opcode_line[1] == 'PUSH9':  # 0x68
                stack_after_moving.append(0)
    
            elif opcode_line[1] == 'PUSH10':  # 0x69
                stack_after_moving.append(0)
    
            elif opcode_line[1] == 'PUSH11':  # 0x6a
                stack_after_moving.append(0)
    
            elif opcode_line[1] == 'PUSH12':  # 0x6b
                stack_after_moving.append(0)
    
            elif opcode_line[1] == 'PUSH13':  # 0x6c
                stack_after_moving.append(0)
    
            elif opcode_line[1] == 'PUSH14':  # 0x6d
                stack_after_moving.append(0)
               
            elif opcode_line[1] == 'PUSH15':  # 0x6e
                stack_after_moving.append(0)
    
            elif opcode_line[1] == 'PUSH16':  # 0x6f
                stack_after_moving.append(0)
    
            elif opcode_line[1] == 'PUSH17':  # 0x70
                stack_after_moving.append(0)
    
            elif opcode_line[1] == 'PUSH18':  # 0x71
                stack_after_moving.append(0)
    
            elif opcode_line[1] == 'PUSH19':  # 0x72
                stack_after_moving.append(0)
    
            elif opcode_line[1] == 'PUSH20':  # 0x73
                stack_after_moving.append(0)
    
            elif opcode_line[1] == 'PUSH21':  # 0x74
                stack_after_moving.append(0)
    
            elif opcode_line[1] == 'PUSH22':  # 0x75
                stack_after_moving.append(0)
    
            elif opcode_line[1] == 'PUSH23':  # 0x76
                stack_after_moving.append(0)
    
            elif opcode_line[1] == 'PUSH24':  # 0x77
                stack_after_moving.append(0)
    
            elif opcode_line[1] == 'PUSH25':  # 0x78
                stack_after_moving.append(0)
    
            elif opcode_line[1] == 'PUSH26':  # 0x79
                stack_after_moving.append(0)
    
            elif opcode_line[1] == 'PUSH27':  # 0x7a
                stack_after_moving.append(0)
    
            elif opcode_line[1] == 'PUSH28':  # 0x7b
                stack_after_moving.append(0)
    
            elif opcode_line[1] == 'PUSH29':  # 0x7c
                stack_after_moving.append(0)
    
            elif opcode_line[1] == 'PUSH30':  # 0x7d
                stack_after_moving.append(0)
    
            elif opcode_line[1] == 'PUSH31':  # 0x7e
                stack_after_moving.append(0)
    
            elif opcode_line[1] == 'PUSH32':  # 0x7f
                stack_after_moving.append(0)
    
            elif opcode_line[1] == 'DUP1':  # 0x80
                stack_after_moving.append(0)
    
            elif opcode_line[1] == 'DUP2':  # 0x81
                stack_after_moving.append(0)
    
            elif opcode_line[1] == 'DUP3':  # 0x82
                stack_after_moving.append(0)
                
            elif opcode_line[1] == 'DUP4':  # 0x83
                stack_after_moving.append(0)
                
            elif opcode_line[1] == 'DUP5':  # 0x84
                stack_after_moving.append(0)
                
            elif opcode_line[1] == 'DUP6':  # 0x85
                stack_after_moving.append(0)
                
            elif opcode_line[1] == 'DUP7':  # 0x86
                stack_after_moving.append(0)
                
            elif opcode_line[1] == 'DUP8':  # 0x87
                stack_after_moving.append(0)
                
            elif opcode_line[1] == 'DUP9':  # 0x88
                stack_after_moving.append(0)
                
            elif opcode_line[1] == 'DUP10':  # 0x89
                stack_after_moving.append(0)
                
            elif opcode_line[1] == 'DUP11':  # 0x8a
                stack_after_moving.append(0)
                
            elif opcode_line[1] == 'DUP12':  # 0x8b
                stack_after_moving.append(0)
                
            elif opcode_line[1] == 'DUP13':  # 0x8c
                stack_after_moving.append(0)
                
            elif opcode_line[1] == 'DUP14':  # 0x8d
                stack_after_moving.append(0)
                
            elif opcode_line[1] == 'DUP15':  # 0x8e
                stack_after_moving.append(0)
                
            elif opcode_line[1] == 'DUP16':  # 0x8f
                stack_after_moving.append(0)
                
            elif opcode_line[1] == 'SWAP1':  # 0x90
                val1 = stack_after_moving.pop()
                val2 = stack_after_moving.pop()
                stack_after_moving.append(val1)
                stack_after_moving.append(val2)
                
            elif opcode_line[1] == 'SWAP2':  # 0x91
                val1 = stack_after_moving.pop()
                val2 = stack_after_moving.pop()
                val3 = stack_after_moving.pop()
                stack_after_moving.append(val1)
                stack_after_moving.append(val2)
                stack_after_moving.append(val3)
                                      
            elif opcode_line[1] == 'SWAP3':  # 0x92
                val1 = stack_after_moving.pop()
                val2 = stack_after_moving.pop()
                val3 = stack_after_moving.pop()
                val4 = stack_after_moving.pop()
                stack_after_moving.append(val1)
                stack_after_moving.append(val3)
                stack_after_moving.append(val2)
                stack_after_moving.append(val4)
                
            elif opcode_line[1] == 'SWAP4':  # 0x93
                val1 = stack_after_moving.pop()
                val2 = stack_after_moving.pop()
                val3 = stack_after_moving.pop()
                val4 = stack_after_moving.pop()
                val5 = stack_after_moving.pop()
                stack_after_moving.append(val1)
                stack_after_moving.append(val4)
                stack_after_moving.append(val3)
                stack_after_moving.append(val2)
                stack_after_moving.append(val5)
                
            elif opcode_line[1] == 'SWAP5':  # 0x94
                val1 = stack_after_moving.pop()
                val2 = stack_after_moving.pop()
                val3 = stack_after_moving.pop()
                val4 = stack_after_moving.pop()
                val5 = stack_after_moving.pop()
                val6 = stack_after_moving.pop()
                stack_after_moving.append(val1)
                stack_after_moving.append(val5)
                stack_after_moving.append(val4)
                stack_after_moving.append(val3)
                stack_after_moving.append(val2)
                stack_after_moving.append(val6)
                
            elif opcode_line[1] == 'SWAP6':  # 0x95
                val1 = stack_after_moving.pop()
                val2 = stack_after_moving.pop()
                val3 = stack_after_moving.pop()
                val4 = stack_after_moving.pop()
                val5 = stack_after_moving.pop()
                val6 = stack_after_moving.pop()
                val7 = stack_after_moving.pop()
                stack_after_moving.append(val1)
                stack_after_moving.append(val6)
                stack_after_moving.append(val5)
                stack_after_moving.append(val4)
                stack_after_moving.append(val3)
                stack_after_moving.append(val2)
                stack_after_moving.append(val7)
                
            elif opcode_line[1] == 'SWAP7':  # 0x96
                val1 = stack_after_moving.pop()
                val2 = stack_after_moving.pop()
                val3 = stack_after_moving.pop()
                val4 = stack_after_moving.pop()
                val5 = stack_after_moving.pop()
                val6 = stack_after_moving.pop()
                val7 = stack_after_moving.pop()
                val8 = stack_after_moving.pop()
                stack_after_moving.append(val1)
                stack_after_moving.append(val7)
                stack_after_moving.append(val6)
                stack_after_moving.append(val5)
                stack_after_moving.append(val4)
                stack_after_moving.append(val3)
                stack_after_moving.append(val2)
                stack_after_moving.append(val8)
                
            elif opcode_line[1] == 'SWAP8':  # 0x97
                val1 = stack_after_moving.pop()
                val2 = stack_after_moving.pop()
                val3 = stack_after_moving.pop()
                val4 = stack_after_moving.pop()
                val5 = stack_after_moving.pop()
                val6 = stack_after_moving.pop()
                val7 = stack_after_moving.pop()
                val8 = stack_after_moving.pop()
                val9 = stack_after_moving.pop()
                stack_after_moving.append(val1)
                stack_after_moving.append(val8)
                stack_after_moving.append(val7)
                stack_after_moving.append(val6)
                stack_after_moving.append(val5)
                stack_after_moving.append(val4)
                stack_after_moving.append(val3)
                stack_after_moving.append(val2)
                stack_after_moving.append(val9)
                
            elif opcode_line[1] == 'SWAP9':  # 0x98
                val1 = stack_after_moving.pop()
                val2 = stack_after_moving.pop()
                val3 = stack_after_moving.pop()
                val4 = stack_after_moving.pop()
                val5 = stack_after_moving.pop()
                val6 = stack_after_moving.pop()
                val7 = stack_after_moving.pop()
                val8 = stack_after_moving.pop()
                val9 = stack_after_moving.pop()
                val10 = stack_after_moving.pop()
                stack_after_moving.append(val1)
                stack_after_moving.append(val9)
                stack_after_moving.append(val8)
                stack_after_moving.append(val7)
                stack_after_moving.append(val6)
                stack_after_moving.append(val5)
                stack_after_moving.append(val4)
                stack_after_moving.append(val3)
                stack_after_moving.append(val2)
                stack_after_moving.append(val10)
                
            elif opcode_line[1] == 'SWAP10':  # 0x99
                val1 = stack_after_moving.pop()
                val2 = stack_after_moving.pop()
                val3 = stack_after_moving.pop()
                val4 = stack_after_moving.pop()
                val5 = stack_after_moving.pop()
                val6 = stack_after_moving.pop()
                val7 = stack_after_moving.pop()
                val8 = stack_after_moving.pop()
                val9 = stack_after_moving.pop()
                val10 = stack_after_moving.pop()
                val11 = stack_after_moving.pop()
                stack_after_moving.append(val1)
                stack_after_moving.append(val10)
                stack_after_moving.append(val9)
                stack_after_moving.append(val8)
                stack_after_moving.append(val7)
                stack_after_moving.append(val6)
                stack_after_moving.append(val5)
                stack_after_moving.append(val4)
                stack_after_moving.append(val3)
                stack_after_moving.append(val2)
                stack_after_moving.append(val11)
                
            elif opcode_line[1] == 'SWAP11':  # 0x9a
                val1 = stack_after_moving.pop()
                val2 = stack_after_moving.pop()
                val3 = stack_after_moving.pop()
                val4 = stack_after_moving.pop()
                val5 = stack_after_moving.pop()
                val6 = stack_after_moving.pop()
                val7 = stack_after_moving.pop()
                val8 = stack_after_moving.pop()
                val9 = stack_after_moving.pop()
                val10 = stack_after_moving.pop()
                val11 = stack_after_moving.pop()
                val12 = stack_after_moving.pop()
                stack_after_moving.append(val1)
                stack_after_moving.append(val11)
                stack_after_moving.append(val10)
                stack_after_moving.append(val9)
                stack_after_moving.append(val8)
                stack_after_moving.append(val7)
                stack_after_moving.append(val6)
                stack_after_moving.append(val5)
                stack_after_moving.append(val4)
                stack_after_moving.append(val3)
                stack_after_moving.append(val2)
                stack_after_moving.append(val12)
                            
            elif opcode_line[1] == 'SWAP12':  # 0x9b
                val1 = stack_after_moving.pop()
                val2 = stack_after_moving.pop()
                val3 = stack_after_moving.pop()
                val4 = stack_after_moving.pop()
                val5 = stack_after_moving.pop()
                val6 = stack_after_moving.pop()
                val7 = stack_after_moving.pop()
                val8 = stack_after_moving.pop()
                val9 = stack_after_moving.pop()
                val10 = stack_after_moving.pop()
                val11 = stack_after_moving.pop()
                val12 = stack_after_moving.pop()
                val13 = stack_after_moving.pop()
                stack_after_moving.append(val1)
                stack_after_moving.append(val12)
                stack_after_moving.append(val11)
                stack_after_moving.append(val10)
                stack_after_moving.append(val9)
                stack_after_moving.append(val8)
                stack_after_moving.append(val7)
                stack_after_moving.append(val6)
                stack_after_moving.append(val5)
                stack_after_moving.append(val4)
                stack_after_moving.append(val3)
                stack_after_moving.append(val2)
                stack_after_moving.append(val13)
                
            elif opcode_line[1] == 'SWAP13':  # 0x9c
                val1 = stack_after_moving.pop()
                val2 = stack_after_moving.pop()
                val3 = stack_after_moving.pop()
                val4 = stack_after_moving.pop()
                val5 = stack_after_moving.pop()
                val6 = stack_after_moving.pop()
                val7 = stack_after_moving.pop()
                val8 = stack_after_moving.pop()
                val9 = stack_after_moving.pop()
                val10 = stack_after_moving.pop()
                val11 = stack_after_moving.pop()
                val12 = stack_after_moving.pop()
                val13 = stack_after_moving.pop()
                val14 = stack_after_moving.pop()
                stack_after_moving.append(val1)
                stack_after_moving.append(val13)
                stack_after_moving.append(val12)
                stack_after_moving.append(val11)
                stack_after_moving.append(val10)
                stack_after_moving.append(val9)
                stack_after_moving.append(val8)
                stack_after_moving.append(val7)
                stack_after_moving.append(val6)
                stack_after_moving.append(val5)
                stack_after_moving.append(val4)
                stack_after_moving.append(val3)
                stack_after_moving.append(val2)
                stack_after_moving.append(val14)
           
            elif opcode_line[1] == 'SWAP14':  # 0x9d
                val1 = stack_after_moving.pop()
                val2 = stack_after_moving.pop()
                val3 = stack_after_moving.pop()
                val4 = stack_after_moving.pop()
                val5 = stack_after_moving.pop()
                val6 = stack_after_moving.pop()
                val7 = stack_after_moving.pop()
                val8 = stack_after_moving.pop()
                val9 = stack_after_moving.pop()
                val10 = stack_after_moving.pop()
                val11 = stack_after_moving.pop()
                val12 = stack_after_moving.pop()
                val13 = stack_after_moving.pop()
                val14 = stack_after_moving.pop()
                val15 = stack_after_moving.pop()
                stack_after_moving.append(val1)
                stack_after_moving.append(val14)
                stack_after_moving.append(val13)
                stack_after_moving.append(val12)
                stack_after_moving.append(val11)
                stack_after_moving.append(val10)
                stack_after_moving.append(val9)
                stack_after_moving.append(val8)
                stack_after_moving.append(val7)
                stack_after_moving.append(val6)
                stack_after_moving.append(val5)
                stack_after_moving.append(val4)
                stack_after_moving.append(val3)
                stack_after_moving.append(val2)
                stack_after_moving.append(val15)            
    
            elif opcode_line[1] == 'SWAP15':  # 0x9e
                val1 = stack_after_moving.pop()
                val2 = stack_after_moving.pop()
                val3 = stack_after_moving.pop()
                val4 = stack_after_moving.pop()
                val5 = stack_after_moving.pop()
                val6 = stack_after_moving.pop()
                val7 = stack_after_moving.pop()
                val8 = stack_after_moving.pop()
                val9 = stack_after_moving.pop()
                val10 = stack_after_moving.pop()
                val11 = stack_after_moving.pop()
                val12 = stack_after_moving.pop()
                val13 = stack_after_moving.pop()
                val14 = stack_after_moving.pop()
                val15 = stack_after_moving.pop()
                val16 = stack_after_moving.pop()
                stack_after_moving.append(val1)
                stack_after_moving.append(val15)
                stack_after_moving.append(val14)
                stack_after_moving.append(val13)
                stack_after_moving.append(val12)
                stack_after_moving.append(val11)
                stack_after_moving.append(val10)
                stack_after_moving.append(val9)
                stack_after_moving.append(val8)
                stack_after_moving.append(val7)
                stack_after_moving.append(val6)
                stack_after_moving.append(val5)
                stack_after_moving.append(val4)
                stack_after_moving.append(val3)
                stack_after_moving.append(val2)
                stack_after_moving.append(val16)           
    
            elif opcode_line[1] == 'SWAP16':  # 0x9f
                val1 = stack_after_moving.pop()
                val2 = stack_after_moving.pop()
                val3 = stack_after_moving.pop()
                val4 = stack_after_moving.pop()
                val5 = stack_after_moving.pop()
                val6 = stack_after_moving.pop()
                val7 = stack_after_moving.pop()
                val8 = stack_after_moving.pop()
                val9 = stack_after_moving.pop()
                val10 = stack_after_moving.pop()
                val11 = stack_after_moving.pop()
                val12 = stack_after_moving.pop()
                val13 = stack_after_moving.pop()
                val14 = stack_after_moving.pop()
                val15 = stack_after_moving.pop()
                val16 = stack_after_moving.pop()
                val17 = stack_after_moving.pop()
                stack_after_moving.append(val1)
                stack_after_moving.append(val16)
                stack_after_moving.append(val15)
                stack_after_moving.append(val14)
                stack_after_moving.append(val13)
                stack_after_moving.append(val12)
                stack_after_moving.append(val11)
                stack_after_moving.append(val10)
                stack_after_moving.append(val9)
                stack_after_moving.append(val8)
                stack_after_moving.append(val7)
                stack_after_moving.append(val6)
                stack_after_moving.append(val5)
                stack_after_moving.append(val4)
                stack_after_moving.append(val3)
                stack_after_moving.append(val2)
                stack_after_moving.append(val17)            
    
            elif opcode_line[1] == 'LOG0':  # 0xa0
                stack_after_moving.pop()
                stack_after_moving.pop()
    
            elif opcode_line[1] == 'LOG1':  # 0xa1
                stack_after_moving.pop()
                stack_after_moving.pop()
                stack_after_moving.pop()
    
            elif opcode_line[1] == 'LOG2':  # 0xa2
                stack_after_moving.pop()
                stack_after_moving.pop()
                stack_after_moving.pop()
                stack_after_moving.pop()
    
            elif opcode_line[1] == 'LOG3':  # 0xa3
                stack_after_moving.pop()
                stack_after_moving.pop()
                stack_after_moving.pop()
                stack_after_moving.pop()
                stack_after_moving.pop()
    
            elif opcode_line[1] == 'LOG4':  # 0xa4
                stack_after_moving.pop()
                stack_after_moving.pop()
                stack_after_moving.pop()
                stack_after_moving.pop()
                stack_after_moving.pop()
                stack_after_moving.pop()
    
            elif opcode_line[1] == 'CREATE':  # 0xf0
                stack_after_moving.pop()
                stack_after_moving.pop()
                stack_after_moving.pop()
                stack_after_moving.append(0)
    
            elif opcode_line[1] == 'CALL':    # 0xf1
                stack_after_moving.pop()
                stack_after_moving.pop()
                stack_after_moving.pop()
                stack_after_moving.pop()
                stack_after_moving.pop()
                stack_after_moving.pop()
                stack_after_moving.pop()
                stack_after_moving.append(0)            
    
            elif opcode_line[1] == 'CALLCODE':  # 0xf2
                stack_after_moving.pop()
                stack_after_moving.pop()
                stack_after_moving.pop()
                stack_after_moving.pop()
                stack_after_moving.pop()
                stack_after_moving.pop()
                stack_after_moving.pop()
                stack_after_moving.append(0)
    
            elif opcode_line[1] == 'RETURN':  # 0xf3
                stack_after_moving.pop()
                stack_after_moving.pop()
    
            elif opcode_line[1] == 'DELEGATECALL':        # 0xf4
                stack_after_moving.pop()
                stack_after_moving.pop()
                stack_after_moving.pop()
                stack_after_moving.pop()
                stack_after_moving.pop()
                stack_after_moving.pop()
                stack_after_moving.append(0)
                    
            elif opcode_line[1] == 'CREATE2':  # 0xf5
                stack_after_moving.pop()
                stack_after_moving.pop()
                stack_after_moving.pop()
                stack_after_moving.pop()
                stack_after_moving.append(0)    
          
            elif opcode_line[1] == 'STATICCALL':  # 0xfa
                stack_after_moving.pop()
                stack_after_moving.pop()
                stack_after_moving.pop()
                stack_after_moving.pop()
                stack_after_moving.pop()
                stack_after_moving.pop()
                stack_after_moving.append(0)                        
                    
            elif opcode_line[1] == 'REVERT':  # 0xfd
                stack_after_moving.pop()
                stack_after_moving.pop()                 
                    
            elif opcode_line[1] == 'INVALID':  # 0xfe
                pass
    
            elif opcode_line[1] == 'SELFDESTRUCT':  # 0xff
                stack_after_moving.pop()
    

            else:
                print(opcode_line[1])                    
                raise Exception("unknown opcode")
                
        return 1

    

    
            
    
    
