
import likely_CR_site_pairings_analyzer

class sm(object):
    def __init__(self):
        self.stack = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]  # Maximum operation depth
        
    
    def sn(self, opcode_name, operand=None):

        if opcode_name == "STOP":
            pass
                            
        elif opcode_name == 'ADD':  # 0x01
            self.stack.pop()
            self.stack.pop()
            self.stack.append(0)
                       
        elif opcode_name == 'MUL':  # 0x02
            self.stack.pop()
            self.stack.pop()
            self.stack.append(0)
                        
        elif opcode_name == 'SUB':  # 0x03
            self.stack.pop()
            self.stack.pop()
            self.stack.append(0)
                      
        elif opcode_name == 'DIV':  # 0x04
            self.stack.pop()
            self.stack.pop()
            self.stack.append(0)
        
        elif opcode_name == 'SDIV':  # 0x05
            self.stack.pop()
            self.stack.pop()
            self.stack.append(0)
                           
        elif opcode_name == 'MOD':  # 0x06
            self.stack.pop()
            self.stack.pop()
            self.stack.append(0)
                        
        elif opcode_name == 'SMOD':  # 0x07
            self.stack.pop()
            self.stack.pop()
            self.stack.append(0)
                      
        elif opcode_name == 'ADDMOD':  # 0x08
            self.stack.pop()
            self.stack.pop()
            self.stack.pop()
            self.stack.append(0)
            
        elif opcode_name == 'MULMOD':  # 0x09
            self.stack.pop()
            self.stack.pop()
            self.stack.pop()
            self.stack.append(0)
                  
        elif opcode_name == 'EXP':  # 0x0a
            self.stack.pop()
            self.stack.pop()
            self.stack.append(0)
            
        elif opcode_name == 'SIGNEXTEND':  # 0x0b
            self.stack.pop()
            self.stack.pop()
            self.stack.append(0)
           
        elif opcode_name == 'LT':  # 0x10
            self.stack.pop()
            self.stack.pop()
            self.stack.append(0)
           
        elif opcode_name == 'GT':  # 0x11
            self.stack.pop()
            self.stack.pop()
            self.stack.append(0)
           
        elif opcode_name == 'SLT':  # 0x12
            self.stack.pop()
            self.stack.pop()
            self.stack.append(0)
            
        elif opcode_name == 'SGT':  # 0x13
            self.stack.pop()
            self.stack.pop()
            self.stack.append(0)
            
        elif opcode_name == 'EQ':  # 0x14
            self.stack.pop()
            self.stack.pop()
            self.stack.append(0)           

        elif opcode_name == 'ISZERO':  # 0x15
            self.stack.pop()
            self.stack.append(0)           

        elif opcode_name == 'AND':  # 0x16
            self.stack.pop()
            self.stack.pop()
            self.stack.append(0)
           
        elif opcode_name == 'OR':  # 0x17
            self.stack.pop()
            self.stack.pop()
            self.stack.append(0)            

        elif opcode_name == 'XOR':  # 0x18
            self.stack.pop()
            self.stack.pop()
            self.stack.append(0)
           
        elif opcode_name == 'NOT':  # 0x19
            self.stack.pop()
            self.stack.append(0)
            
        elif opcode_name == 'BYTE':  # 0x1a
            self.stack.pop()
            self.stack.pop()
            self.stack.append(0)
           
        elif opcode_name == 'SHL':   #0x1b
            self.stack.pop()
            self.stack.pop()
            self.stack.append(0)
            
        elif opcode_name == 'SHR':   #0x1c
            self.stack.pop()
            self.stack.pop()
            self.stack.append(0)
            
        elif opcode_name == 'SAR':   #0x1d
            self.stack.pop()
            self.stack.pop()
            self.stack.append(0)

        elif opcode_name == 'SHA3':  # 0x20
            self.stack.pop()
            self.stack.pop()
            self.stack.append(0)            

        elif opcode_name == 'KECCAK256':  # 0x20
            self.stack.pop()
            self.stack.pop()
            self.stack.append(0) 


        elif opcode_name == 'ADDRESS':  # 0x30
            self.stack.append(0)           

        elif opcode_name == 'BALANCE':  # 0x31
            self.stack.pop()
            self.stack.append(0)            

        elif opcode_name == 'ORIGIN':  # 0x32
            self.stack.append(0)
            
        elif opcode_name == 'CALLER':  # 0x33
            self.stack.append(0)
          
        elif opcode_name == 'CALLVALUE':  # 0x34
            self.stack.append(0)
            
        elif opcode_name == 'CALLDATALOAD':  # 0x35
            self.stack.pop()
            self.stack.append(0)
            
        elif opcode_name == 'CALLDATASIZE':  # 0x36
            self.stack.append(0)
            
        elif opcode_name == 'CALLDATACOPY':  # 0x37
            self.stack.pop()
            self.stack.pop()
            self.stack.pop()
            
        elif opcode_name == 'CODESIZE':  # 0x38
            self.stack.append(0)            

        elif opcode_name == 'CODECOPY':  # 0x39
            self.stack.pop()
            self.stack.pop()
            self.stack.pop()

        elif opcode_name == 'GASPRICE':  # 0x3a
            self.stack.append(0) 
            
        elif opcode_name == 'EXTCODESIZE':  # 0x3b
            self.stack.pop()
            self.stack.append(0)
    
        elif opcode_name == 'EXTCODECOPY':  # 0x3c
            self.stack.pop()
            self.stack.pop()
            self.stack.pop()
            self.stack.pop()

        elif opcode_name == 'RETURNDATASIZE':  # 0x3d
            self.stack.append(0)

        elif opcode_name == 'RETURNDATACOPY':  # 0x3e
            self.stack.pop()
            self.stack.pop()
            self.stack.pop()

        elif opcode_name == 'EXTCODEHASH':  # 0x3f
            self.stack.pop()
            self.stack.append(0)

        elif opcode_name == 'BLOCKHASH':  # 0x40
            self.stack.pop()
            self.stack.append(0)

        elif opcode_name == 'COINBASE':  # 0x41
            self.stack.append(0)
            
        elif opcode_name == 'TIMESTAMP':  # 0x42
            self.stack.append(0)
            
        elif opcode_name == 'NUMBER':  # 0x43
            self.stack.append(0)
            
        elif opcode_name == 'DIFFICULTY':  # 0x44
            self.stack.append(0)
            
        elif opcode_name == 'GASLIMIT':  # 0x45
            self.stack.append(0)
                      
        elif opcode_name == 'CHAINID':  # 0x46
            self.stack.append(0)
                     
        elif opcode_name == 'SELFBALANCE':  # 0x47
            self.stack.append(0)   

        elif opcode_name == 'BASEFEE':  # 0x48
            self.stack.append(0)

        elif opcode_name == 'POP':  # 0x50
            self.stack.pop()
           
        elif opcode_name == 'MLOAD':  # 0x51
            self.stack.pop()
            self.stack.append(0)

        elif opcode_name == 'MSTORE':# 0x52       
            self.stack.pop()
            self.stack.pop()

        elif opcode_name == 'MSTORE8':# 0x53
            self.stack.pop()
            self.stack.pop()

        elif opcode_name == 'SLOAD':  # 0x54
            self.stack.pop()
            self.stack.append(0)

        elif opcode_name == 'SSTORE':  # 0x55
            self.stack.pop()
            self.stack.pop()

        elif opcode_name == 'JUMP':  # 0x56
            self.stack.pop()
            
        elif opcode_name == 'REQUIRE':
            self.stack.pop()
            
        elif opcode_name == 'ASSERT':
            self.stack.pop()
                        
        elif opcode_name == 'JUMPI':  # 0x57
            self.stack.pop()
            self.stack.pop()

        elif opcode_name == 'PC':  # 0x58
            self.stack.append(0)

        elif opcode_name == 'MSIZE':  # 0x59
            self.stack.append(0)

        elif opcode_name == 'GAS':  # 0x5a
            self.stack.append(0)

        elif opcode_name == 'JUMPDEST':  # 0x5b
            pass

        

        elif opcode_name == 'TLOAD':  # 0x5c
            pass 

        elif opcode_name == 'TSTORE':  # 0x5D
            self.stack.pop()
            self.stack.pop()

        elif opcode_name == 'MCOPY':  # 0x5E
            self.stack.pop()
            self.stack.pop()
            self.stack.pop()


        elif opcode_name == 'PUSH0':  # 0x5f
            self.stack.append(0)  



        elif opcode_name == 'PUSH1':  # 0x60
            self.stack.append(0)

        elif opcode_name == 'PUSH2':  # 0x61
            self.stack.append(0)

        elif opcode_name == 'PUSH3':  # 0x62
            self.stack.append(0)

        elif opcode_name == 'PUSH4':  # 0x63
            self.stack.append(0)

        elif opcode_name == 'PUSH5':  # 0x64
            self.stack.append(0)

        elif opcode_name == 'PUSH6':  # 0x65
            self.stack.append(0)

        elif opcode_name == 'PUSH7':  # 0x66
            self.stack.append(0)

        elif opcode_name == 'PUSH8':  # 0x67
            self.stack.append(0)

        elif opcode_name == 'PUSH9':  # 0x68
            self.stack.append(0)

        elif opcode_name == 'PUSH10':  # 0x69
            self.stack.append(0)

        elif opcode_name == 'PUSH11':  # 0x6a
            self.stack.append(0)

        elif opcode_name == 'PUSH12':  # 0x6b
            self.stack.append(0)

        elif opcode_name == 'PUSH13':  # 0x6c
            self.stack.append(0)

        elif opcode_name == 'PUSH14':  # 0x6d
            self.stack.append(0)
           
        elif opcode_name == 'PUSH15':  # 0x6e
            self.stack.append(0)

        elif opcode_name == 'PUSH16':  # 0x6f
            self.stack.append(0)

        elif opcode_name == 'PUSH17':  # 0x70
            self.stack.append(0)

        elif opcode_name == 'PUSH18':  # 0x71
            self.stack.append(0)

        elif opcode_name == 'PUSH19':  # 0x72
            self.stack.append(0)

        elif opcode_name == 'PUSH20':  # 0x73
            self.stack.append(0)

        elif opcode_name == 'PUSH21':  # 0x74
            self.stack.append(0)

        elif opcode_name == 'PUSH22':  # 0x75
            self.stack.append(0)

        elif opcode_name == 'PUSH23':  # 0x76
            self.stack.append(0)

        elif opcode_name == 'PUSH24':  # 0x77
            self.stack.append(0)

        elif opcode_name == 'PUSH25':  # 0x78
            self.stack.append(0)

        elif opcode_name == 'PUSH26':  # 0x79
            self.stack.append(0)

        elif opcode_name == 'PUSH27':  # 0x7a
            self.stack.append(0)

        elif opcode_name == 'PUSH28':  # 0x7b
            self.stack.append(0)

        elif opcode_name == 'PUSH29':  # 0x7c
            self.stack.append(0)

        elif opcode_name == 'PUSH30':  # 0x7d
            self.stack.append(0)

        elif opcode_name == 'PUSH31':  # 0x7e
            self.stack.append(0)

        elif opcode_name == 'PUSH32':  # 0x7f
            self.stack.append(0)

        elif opcode_name == 'DUP1':  # 0x80
            self.stack.append(0)

        elif opcode_name == 'DUP2':  # 0x81
            self.stack.append(0)

        elif opcode_name == 'DUP3':  # 0x82
            self.stack.append(0)
            
        elif opcode_name == 'DUP4':  # 0x83
            self.stack.append(0)
            
        elif opcode_name == 'DUP5':  # 0x84
            self.stack.append(0)
            
        elif opcode_name == 'DUP6':  # 0x85
            self.stack.append(0)
            
        elif opcode_name == 'DUP7':  # 0x86
            self.stack.append(0)
            
        elif opcode_name == 'DUP8':  # 0x87
            self.stack.append(0)
            
        elif opcode_name == 'DUP9':  # 0x88
            self.stack.append(0)
            
        elif opcode_name == 'DUP10':  # 0x89
            self.stack.append(0)
            
        elif opcode_name == 'DUP11':  # 0x8a
            self.stack.append(0)
            
        elif opcode_name == 'DUP12':  # 0x8b
            self.stack.append(0)
            
        elif opcode_name == 'DUP13':  # 0x8c
            self.stack.append(0)
            
        elif opcode_name == 'DUP14':  # 0x8d
            self.stack.append(0)
            
        elif opcode_name == 'DUP15':  # 0x8e
            self.stack.append(0)
            
        elif opcode_name == 'DUP16':  # 0x8f
            self.stack.append(0)
            
        elif opcode_name == 'SWAP1':  # 0x90
            pass
            
        elif opcode_name == 'SWAP2':  # 0x91
            pass
                                  
        elif opcode_name == 'SWAP3':  # 0x92
            pass
            
        elif opcode_name == 'SWAP4':  # 0x93
            pass
            
        elif opcode_name == 'SWAP5':  # 0x94
            pass
            
        elif opcode_name == 'SWAP6':  # 0x95
            pass
            
        elif opcode_name == 'SWAP7':  # 0x96
            pass
            
        elif opcode_name == 'SWAP8':  # 0x97
            pass
            
        elif opcode_name == 'SWAP9':  # 0x98
            pass
            
        elif opcode_name == 'SWAP10':  # 0x99
            pass
            
        elif opcode_name == 'SWAP11':  # 0x9a
            pass
                        
        elif opcode_name == 'SWAP12':  # 0x9b
            pass
            
        elif opcode_name == 'SWAP13':  # 0x9c
            pass
       
        elif opcode_name == 'SWAP14':  # 0x9d
            pass            

        elif opcode_name == 'SWAP15':  # 0x9e
            pass            

        elif opcode_name == 'SWAP16':  # 0x9f
            pass            

        elif opcode_name == 'LOG0':  # 0xa0
            self.stack.pop()
            self.stack.pop()

        elif opcode_name == 'LOG1':  # 0xa1
            self.stack.pop()
            self.stack.pop()
            self.stack.pop()

        elif opcode_name == 'LOG2':  # 0xa2
            self.stack.pop()
            self.stack.pop()
            self.stack.pop()
            self.stack.pop()

        elif opcode_name == 'LOG3':  # 0xa3
            self.stack.pop()
            self.stack.pop()
            self.stack.pop()
            self.stack.pop()
            self.stack.pop()

        elif opcode_name == 'LOG4':  # 0xa4
            self.stack.pop()
            self.stack.pop()
            self.stack.pop()
            self.stack.pop()
            self.stack.pop()
            self.stack.pop()

        elif opcode_name == 'CREATE':  # 0xf0
            self.stack.pop()
            self.stack.pop()
            self.stack.pop()
            self.stack.append(0)

        elif opcode_name == 'CALL':    # 0xf1
            self.stack.pop()
            self.stack.pop()
            self.stack.pop()
            self.stack.pop()
            self.stack.pop()
            self.stack.pop()
            self.stack.pop()
            self.stack.append(0)            

        elif opcode_name == 'CALLCODE':  # 0xf2
            self.stack.pop()
            self.stack.pop()
            self.stack.pop()
            self.stack.pop()
            self.stack.pop()
            self.stack.pop()
            self.stack.pop()
            self.stack.append(0)

        elif opcode_name == 'RETURN':  # 0xf3
            self.stack.pop()
            self.stack.pop()

        elif opcode_name == 'DELEGATECALL':        # 0xf4
            self.stack.pop()
            self.stack.pop()
            self.stack.pop()
            self.stack.pop()
            self.stack.pop()
            self.stack.pop()
            self.stack.append(0)
                
        elif opcode_name == 'CREATE2':  # 0xf5
            self.stack.pop()
            self.stack.pop()
            self.stack.pop()
            self.stack.pop()
            self.stack.append(0)    
      
        elif opcode_name == 'STATICCALL':  # 0xfa
            self.stack.pop()
            self.stack.pop()
            self.stack.pop()
            self.stack.pop()
            self.stack.pop()
            self.stack.pop()
            self.stack.append(0)                        
                
        elif opcode_name == 'REVERT':  # 0xfd
            self.stack.pop()
            self.stack.pop()                 
                
        elif opcode_name == 'INVALID':  # 0xfe
            pass

        elif opcode_name == 'SELFDESTRUCT':  # 0xff
            self.stack.pop()

        elif opcode_name == '95':  # accident
            pass
            
        else:
            print(opcode_name)
            raise Exception("unknown opcode")
            

    
    def so(self, likely_call_site):
        for code_line in likely_call_site:
            #if len(code_line) == 3:
            #    self.stack_hight_calculation(code_line[1], code_line[2])
            #if len(code_line) == 2:
            self.sn(code_line[1])
        return len(self.stack) - 16
    
    def sp(self, likely_call_site):
        opcode_in_this_site = []
        for code_line in likely_call_site:
            opcode_in_this_site.append(code_line[1])
        if ('SLOAD' in opcode_in_this_site or 'GAS' in opcode_in_this_site or 
            'MSIZE' in opcode_in_this_site or 'BLOBBASEFEE' in opcode_in_this_site or 
            'BLOBHASH' in opcode_in_this_site or 'BASEFEE' in opcode_in_this_site or 
            'SELFBALANCE' in opcode_in_this_site or 'CHAINID' in opcode_in_this_site or 
            'GASLIMIT' in opcode_in_this_site or 'PREVRANDAO' in opcode_in_this_site or 
            'NUMBER' in opcode_in_this_site or 'TIMESTAMP' in opcode_in_this_site or 
            'COINBASE' in opcode_in_this_site or 'BLOCKHASH' in opcode_in_this_site or 
            'EXTCODEHASH' in opcode_in_this_site or 'EXTCODESIZE' in opcode_in_this_site or 
            'GASPRICE' in opcode_in_this_site or 'CODESIZE' in opcode_in_this_site or 
            'CALLER' in opcode_in_this_site or 'ORIGIN' in opcode_in_this_site or 
            'BALANCE' in opcode_in_this_site or 'DIFFICULTY' in opcode_in_this_site):
            return 'YES'
        else:
            return 'NO'
            
                           
    
    def sq(self, likely_call_site):
        if self.sp(likely_call_site) == 'YES':
            return 1, self.so(likely_call_site)
        else:
            return 0, self.so(likely_call_site)
        
            
        
