



from likely_CR_site_pairings_analyzer import OverapproximateCallReturnSitePairings
from collections import Counter

class saf(object):
    def __init__(self, path, pair):
        self.path = path
        self.pair = pair
        
    def sag(self):
        try:
            return self.path.index(self.pair[0])
        except ValueError:
            return -1  
        
    
    def sah(self):
        try:
            return len(self.path) - 1 - self.path[::-1].index(self.pair[-1])
        except ValueError:
            return -1  


    def sai(self):
        first_index = self.sag()
        last_index = self.sah()
        

        if first_index == -1 or last_index == -1:
            return -1
        

        difference = abs(last_index - first_index + 1)
        ratio = difference /  len(self.path)

        
        if ratio > 0.8:

            return 'NO'
        else:
            return 'YES'
            
        
  



    
    
