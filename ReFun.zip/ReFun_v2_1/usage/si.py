

from likely_CR_site_pairings_analyzer import OverapproximateCallReturnSitePairings
class sar(object):
    def __init__(self, path, pair):
        self.path = path
        self.pair = pair

    def sas(self):
        start_index = self.path.index(self.pair[0])  
        end_index = self.path.index(self.pair[-1]) + 1
        sub_path = self.path[start_index:end_index]

        return sub_path
    
    def sat(self):
        for block in self.sas():
            count = 0
            for key in OverapproximateCallReturnSitePairings(asm_file='disassembly_result.txt').get_all_likely_CR_site_pair().keys():
                if block in key:
                    count += 1

                if count >= 2:
                    return "NO"

        return "YES"
            
   
