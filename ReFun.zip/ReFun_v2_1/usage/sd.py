

from likely_CR_site_pairings_analyzer import OverapproximateCallReturnSitePairings
class sz(object):
    def __init__(self, path, pair):
        self.path = path
        self.pair = pair
        
    def saa(self):
        indices = [i for i, x in enumerate(self.path) if x == self.pair[-1]] 
        index_list = []
        for index in indices:
            if index + 1 < len(self.path):
                index_list.append(index + 1)


        return index_list

    
    def sab(self):
        code = OverapproximateCallReturnSitePairings(asm_file='disassembly_result.txt').blocks
        end_op = ['RETURN', 'STOP']
        counter_end_op = 0
        for block in self.path:
            if code[block][-1][-1] in end_op:
                counter_end_op = counter_end_op + 1
        for index in self.saa():
            if code[self.path[index]][-1][-1] in end_op and counter_end_op == 1:
                return 'NO'
        return 'YES'
                
        
     
                
