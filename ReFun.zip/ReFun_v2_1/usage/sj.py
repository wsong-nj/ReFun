
from likely_CR_site_pairings_analyzer import OverapproximateCallReturnSitePairings
class sau(object):
    def __init__(self, path, pair):
        self.path = path
        self.pair = pair

    def sas(self):
        start_index = self.path.index(self.pair[0])  
        end_index = self.path.index(self.pair[-1]) + 1
        sub_path = self.path[start_index:end_index]
        return sub_path

    def sav(self, block_x, block_y):
       
        x = int(block_x.split('_')[1])  
        y = int(block_y.split('_')[1])
    
        return x == y - 1

    def saw(self):
 
        if len(self.sas()) > 2:
            block_before_return_site = self.sas()[-2]
        elif 0 < len(self.sas()) < 3:
            block_before_return_site = self.sas()[0]

        else:

            return 'NO'
        

        if self.sav(block_before_return_site, self.pair[-1]):
            if 'JUMP' in OverapproximateCallReturnSitePairings(asm_file='disassembly_result.txt').blocks[block_before_return_site][-1][1] and len(OverapproximateCallReturnSitePairings(asm_file='disassembly_result.txt').blocks[block_before_return_site][-2]) < 3:
                return 'NO'
            else:
                return 'YES'
                
        if not self.sav(block_before_return_site, self.pair[-1]) and len(OverapproximateCallReturnSitePairings(asm_file='disassembly_result.txt').blocks[block_before_return_site][-2]) < 3:
            return 'NO'

        return 'YES'
    

