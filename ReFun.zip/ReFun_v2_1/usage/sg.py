
from likely_CR_site_pairings_analyzer import OverapproximateCallReturnSitePairings
class saj(object):
    def __init__(self, path, pair):
        self.path = path
        self.pair = pair
        
    def sak(self):
        for i in range(len(self.path) - 1):  
            if (self.path[i] == self.pair[0] and self.path[i + 1] == self.pair[1]):
                return True
        return False        
   
    def sal(self):
        code = OverapproximateCallReturnSitePairings(asm_file='disassembly_result.txt').blocks
        low_level_operation_cabinet = ['JUM', 'PUS', 'MLO', 'SWA', 'DUP', 'ADD', 'MST', 'POP']           
        for line in code[self.pair[0]]:
            if all(any(line[1].startswith(cabinet) for cabinet in low_level_operation_cabinet) for line in code[self.pair[0]]):
                return True
            return False
                    
    def sam(self):
        code = OverapproximateCallReturnSitePairings(asm_file='disassembly_result.txt').blocks
        low_level_operation_cabinet = ['JUM', 'PUS', 'MLO', 'SWA', 'DUP', 'ADD', 'MST', 'POP', 'AND']           
        for line in code[self.pair[1]]:
            if all(any(line[1].startswith(cabinet) for cabinet in low_level_operation_cabinet) for line in code[self.pair[1]]):
                return True
            return False
        
    def san(self):
        if self.sak() and self.sal and self.sam():
            return 'NO'
        else:
            return 'YES'

        

        
