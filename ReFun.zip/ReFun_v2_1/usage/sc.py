
class sv(object):
    def __init__(self, likely_CR_pair, path):
        self.path = path
        self.likely_CR_pair = likely_CR_pair
        
    def sw(self):
        call_site_index = self.path.index(self.likely_CR_pair[0])
        return self.path[call_site_index + 1]
    
    def sx(self):
        ending_point = self.sw().split("_")[-1]
        starting_point = self.likely_CR_pair[0].split("_")[-1]
        distance = abs(int(ending_point) - int(starting_point))

        return distance
    
    def sy(self):
        difference = abs(self.sx())
        max_number = max(int(item.split('_')[-1]) for item in self.path)
        ratio = difference /  max_number
        return ratio    


            

