
from likely_CR_site_pairings_analyzer import OverapproximateCallReturnSitePairings
from collections import Counter

class sac(object):
    def __init__(self, path, pair):
        self.path = path
        self.pair = pair
        
    def sad(self):
        counter = Counter(self.path)
        duplicates = [item for item, count in counter.items() if count > 1]
        return duplicates
        
    
    def sae(self):
        block_involved_with_loop = self.sad()
        for site in self.pair:
            if site in block_involved_with_loop:
                return 'NO'
            
        return 'YES'
            
        
  



    
    
