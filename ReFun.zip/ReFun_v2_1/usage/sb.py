

from path_through_function import PathThroughFunction
from sa import sm
class sr(object):
    def __init__(self, likely_CR_pair, path):
        self.path = path
        self.likely_CR_pair = likely_CR_pair
        
    def ss(self):
        start_index = self.path.index(self.likely_CR_pair[0])
        end_index = self.path.index(self.likely_CR_pair[1])
        return self.path[start_index:end_index]
    
    def st(self):

        hight_calculator = sm()
        block_dictionary = PathThroughFunction(asm_file = 'disassembly_result.txt').blocks
        for block_index in self.ss():
            for code_line in block_dictionary[block_index]:
                hight_calculator.sn(code_line[1])

        return len(hight_calculator.stack) - 16

    def su(self):
        return self.st()
            

      
            

