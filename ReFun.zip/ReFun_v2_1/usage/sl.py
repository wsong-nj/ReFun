
from public_state_variables_elimination import StateVariableElimination
from sa import sm
from sb import sr
from sc import sv
from sd import sz
from se import sac
from sf import saf
from sg import saj
from sh import sao
from si import sar
from sj import sau
from sk import sax
class saz(object):
    def __init__(self, function_path, call_site, return_site):
        self.asm_file = 'disassembly_result.txt'
        self.path = function_path
        self.caller = call_site
        self.returner = return_site
        self.blocks = self.sba(self.asm_file)   # a dictionary
        self.hint_results = []

    def sba(self, asm_file):
        with open(asm_file, 'r') as f:
            content = f.read()
        paragraphs = content.split('\n\n')
        result = {}
        for p in paragraphs:
            lines = p.split('\n')
            index = None
            elements = []
            found_first_line = False
            for line in lines:
                if line.strip() != "":
                    if not found_first_line:
                        index = line.strip()
                        found_first_line = True
                    else:
                        elements.append(line.split())
            if found_first_line:
                result[index] = elements
        return result 

    def sbb(self):
        n_s = StateVariableElimination(self.path, [self.caller, self.returner]).are_the_first_two_blocks()
        z_1, z_1_1 = sm().sq(self.blocks[self.caller])
        z_2 = sr([self.caller, self.returner], self.path).su()
        z_3 = sv([self.caller, self.returner], self.path).sy()
        z_4 = sz(self.path, [self.caller, self.returner]).sab()
        z_5 = sac(self.path, [self.caller, self.returner]).sae()
        z_6 = saf(self.path, [self.caller, self.returner]).sai()
        z_7 = saj(self.path, [self.caller, self.returner]).san()
        z_8 = sao(self.path, [self.caller, self.returner]).saq()
        z_9 = sar(self.path, [self.caller, self.returner]).sat()
        z_10 = sau(self.path, [self.caller, self.returner]).saw()
        z_11 = sax(self.path, [self.caller, self.returner]).say()
        
        self.z_lists = [z_1, z_2, z_3, z_4, z_5, z_6, z_7, z_8, z_9, n_s, z_10, z_11, z_1_1]
        
        return self.z_lists
              

  
