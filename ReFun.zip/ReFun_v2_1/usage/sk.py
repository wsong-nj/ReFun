

from likely_CR_site_pairings_analyzer import OverapproximateCallReturnSitePairings
class sax(object):
    BAD_OPCODE = ['CALLDATASIZE', 'CALLDATALOAD']
    VALUABLE_OPCODE = ['BLOCKHASH', 'COINBASE', 'TIMESTAMP', 'NUMBER', 'PREVRANDAO', 'GASLIMIT', 
                       'CHAINID', 'SELFBALANCE', 'BASEFEE', 'BLOBHASH', 'BLOBBASEFEE', 'SELFDESTRUCT']
    
    def __init__(self, path, pair, asm_file='disassembly_result.txt'):
        self.path = path
        self.pair = pair
        self.asm_file = asm_file
        self.analyzer = OverapproximateCallReturnSitePairings(asm_file=self.asm_file)

    def sas(self):
        start_index = self.path.index(self.pair[0])  
        end_index = self.path.index(self.pair[-1]) + 1
        return self.path[start_index:end_index]

    def say(self):
        for block in self.sas():
            for codeline in self.analyzer.blocks[block]:
                if codeline[1] in self.BAD_OPCODE:
                    return 0
                if codeline[1] in self.VALUABLE_OPCODE:
                    return 1
        return 0



