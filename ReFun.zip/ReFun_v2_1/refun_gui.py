#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Tkinter interface for single and batch ReFun analysis."""

import queue
import re
import os
import signal
import subprocess
import sys
import threading
from collections import deque
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext, ttk


PROJECT_DIR = Path(__file__).resolve().parent
SINGLE_RUNNER = PROJECT_DIR / "run_ReFun.py"
BATCH_RUNNER = PROJECT_DIR / "run_ReFun_auto.py"
INPUT_BYTECODE_FILE = PROJECT_DIR / "input_bytecode"
SINGLE_FINAL_FILE = PROJECT_DIR / "output_functions_final"


class ReFunGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("ReFun Function Recovery")
        self.root.geometry("1080x780")
        self.root.minsize(820, 600)
        self.colors = {
            "background": "#0B1220",
            "surface": "#111827",
            "surface_alt": "#172033",
            "border": "#263247",
            "text": "#E5E7EB",
            "muted": "#94A3B8",
            "accent": "#2DD4BF",
            "accent_hover": "#5EEAD4",
            "editor": "#09101D",
        }
        self.root.configure(background=self.colors["background"])
        self._configure_styles()

        self.events = queue.Queue()
        self.process = None
        self.run_mode = None
        self.stop_requested = False
        self.recent_batch_results = deque(maxlen=3)
        self.batch_statistics = None

        self.status_text = tk.StringVar(value="Ready")
        self.batch_input_folder = tk.StringVar(
            value=str(PROJECT_DIR / "inputs(wild contracts)")
        )
        self.batch_output_folder = tk.StringVar(
            value=str(PROJECT_DIR / "outputs(extracted functions)")
        )

        self._build_interface()
        self._load_existing_bytecode()
        self.root.after(100, self._poll_events)

    def _configure_styles(self):
        style = ttk.Style(self.root)
        style.theme_use("clam")
        style.configure(
            ".",
            background=self.colors["background"],
            foreground=self.colors["text"],
            font=("Segoe UI", 10),
        )
        style.configure("TFrame", background=self.colors["background"])
        style.configure(
            "Card.TFrame",
            background=self.colors["surface"],
            relief="flat",
        )
        style.configure(
            "Title.TLabel",
            background=self.colors["background"],
            foreground=self.colors["text"],
            font=("Segoe UI Semibold", 24),
        )
        style.configure(
            "Subtitle.TLabel",
            background=self.colors["background"],
            foreground=self.colors["muted"],
            font=("Segoe UI", 10),
        )
        style.configure(
            "CardTitle.TLabel",
            background=self.colors["surface"],
            foreground=self.colors["text"],
            font=("Segoe UI Semibold", 11),
        )
        style.configure(
            "CardHint.TLabel",
            background=self.colors["surface"],
            foreground=self.colors["muted"],
            font=("Segoe UI", 9),
        )
        style.configure(
            "Status.TLabel",
            background=self.colors["surface"],
            foreground=self.colors["muted"],
            font=("Segoe UI Semibold", 9),
        )
        style.configure(
            "Accent.TButton",
            background=self.colors["accent"],
            foreground="#07111D",
            borderwidth=0,
            padding=(18, 9),
            font=("Segoe UI Semibold", 10),
        )
        style.map(
            "Accent.TButton",
            background=[
                ("active", self.colors["accent_hover"]),
                ("disabled", self.colors["border"]),
            ],
            foreground=[("disabled", self.colors["muted"])],
        )
        style.configure(
            "Secondary.TButton",
            background=self.colors["surface_alt"],
            foreground=self.colors["text"],
            bordercolor=self.colors["border"],
            padding=(14, 8),
            font=("Segoe UI Semibold", 9),
        )
        style.map(
            "Secondary.TButton",
            background=[("active", self.colors["border"])],
        )
        style.configure(
            "Danger.TButton",
            background="#7F1D1D",
            foreground="#FEE2E2",
            borderwidth=0,
            padding=(12, 7),
            font=("Segoe UI Semibold", 9),
        )
        style.map(
            "Danger.TButton",
            background=[
                ("active", "#991B1B"),
                ("disabled", self.colors["border"]),
            ],
            foreground=[("disabled", self.colors["muted"])],
        )
        style.configure(
            "Path.TEntry",
            fieldbackground=self.colors["editor"],
            foreground=self.colors["text"],
            insertcolor=self.colors["text"],
            bordercolor=self.colors["border"],
            padding=8,
        )
        style.configure(
            "TNotebook",
            background=self.colors["background"],
            borderwidth=0,
            tabmargins=(0, 8, 0, 0),
        )
        style.configure(
            "TNotebook.Tab",
            background=self.colors["surface_alt"],
            foreground=self.colors["muted"],
            borderwidth=0,
            padding=(18, 9),
            font=("Segoe UI Semibold", 9),
        )
        style.map(
            "TNotebook.Tab",
            background=[("selected", self.colors["surface"])],
            foreground=[("selected", self.colors["accent"])],
        )
        style.configure(
            "Refun.Horizontal.TProgressbar",
            background=self.colors["accent"],
            troughcolor=self.colors["editor"],
            borderwidth=0,
            lightcolor=self.colors["accent"],
            darkcolor=self.colors["accent"],
        )

    def _make_code_area(self, parent, height):
        return scrolledtext.ScrolledText(
            parent,
            height=height,
            wrap=tk.NONE,
            font=("Cascadia Mono", 10),
            background=self.colors["editor"],
            foreground="#CBD5E1",
            insertbackground=self.colors["accent"],
            selectbackground="#164E63",
            selectforeground="#F8FAFC",
            relief=tk.FLAT,
            borderwidth=0,
            padx=12,
            pady=10,
        )

    def _build_interface(self):
        container = ttk.Frame(self.root, padding=(22, 18, 22, 20))
        container.pack(fill=tk.BOTH, expand=True)

        header = ttk.Frame(container)
        header.pack(fill=tk.X, pady=(0, 12))
        ttk.Label(header, text="ReFun", style="Title.TLabel").pack(
            side=tk.LEFT
        )
        ttk.Label(
            header,
            text="EVM function recovery and basic-block extraction",
            style="Subtitle.TLabel",
        ).pack(side=tk.LEFT, padx=(14, 0), pady=(10, 0))

        notebook = ttk.Notebook(container)
        notebook.pack(fill=tk.X)
        single_tab = ttk.Frame(notebook, style="Card.TFrame", padding=16)
        batch_tab = ttk.Frame(notebook, style="Card.TFrame", padding=16)
        notebook.add(single_tab, text="Single analysis")
        notebook.add(batch_tab, text="Batch analysis")

        ttk.Label(
            single_tab,
            text="Runtime bytecode",
            style="CardTitle.TLabel",
        ).pack(anchor=tk.W)
        ttk.Label(
            single_tab,
            text="Paste hexadecimal EVM bytecode. Whitespace and a leading 0x are accepted.",
            style="CardHint.TLabel",
        ).pack(anchor=tk.W, pady=(2, 8))
        self.bytecode_text = self._make_code_area(single_tab, height=8)
        self.bytecode_text.configure(wrap=tk.CHAR)
        self.bytecode_text.pack(fill=tk.X, expand=True)

        single_buttons = ttk.Frame(single_tab, style="Card.TFrame")
        single_buttons.pack(fill=tk.X, pady=(12, 0))
        ttk.Button(
            single_buttons,
            text="Load bytecode file",
            style="Secondary.TButton",
            command=self._load_bytecode_file,
        ).pack(side=tk.LEFT)
        self.single_run_button = ttk.Button(
            single_buttons,
            text="Run single analysis",
            style="Accent.TButton",
            command=self._start_single_run,
        )
        self.single_run_button.pack(side=tk.RIGHT)

        ttk.Label(
            batch_tab,
            text="Batch workspace",
            style="CardTitle.TLabel",
        ).pack(anchor=tk.W)
        ttk.Label(
            batch_tab,
            text="Every source file is preserved and produces one final function result.",
            style="CardHint.TLabel",
        ).pack(anchor=tk.W, pady=(2, 12))

        input_row = ttk.Frame(batch_tab, style="Card.TFrame")
        input_row.pack(fill=tk.X, pady=4)
        ttk.Label(
            input_row,
            text="Input folder",
            width=14,
            style="CardHint.TLabel",
        ).pack(side=tk.LEFT)
        ttk.Entry(
            input_row,
            textvariable=self.batch_input_folder,
            style="Path.TEntry",
        ).pack(side=tk.LEFT, fill=tk.X, expand=True)
        ttk.Button(
            input_row,
            text="Browse",
            style="Secondary.TButton",
            command=self._choose_input_folder,
        ).pack(side=tk.LEFT, padx=(10, 0))

        output_row = ttk.Frame(batch_tab, style="Card.TFrame")
        output_row.pack(fill=tk.X, pady=4)
        ttk.Label(
            output_row,
            text="Output folder",
            width=14,
            style="CardHint.TLabel",
        ).pack(side=tk.LEFT)
        ttk.Entry(
            output_row,
            textvariable=self.batch_output_folder,
            style="Path.TEntry",
        ).pack(side=tk.LEFT, fill=tk.X, expand=True)
        ttk.Button(
            output_row,
            text="Browse",
            style="Secondary.TButton",
            command=self._choose_output_folder,
        ).pack(side=tk.LEFT, padx=(10, 0))

        self.batch_run_button = ttk.Button(
            batch_tab,
            text="Run batch analysis",
            style="Accent.TButton",
            command=self._start_batch_run,
        )
        self.batch_run_button.pack(anchor=tk.E, pady=(12, 0))

        progress_card = ttk.Frame(
            container,
            style="Card.TFrame",
            padding=(14, 10),
        )
        progress_card.pack(fill=tk.X, pady=(14, 12))
        self.progress = ttk.Progressbar(
            progress_card,
            mode="determinate",
            maximum=1,
            style="Refun.Horizontal.TProgressbar",
        )
        self.progress.pack(side=tk.LEFT, fill=tk.X, expand=True)
        ttk.Label(
            progress_card,
            textvariable=self.status_text,
            width=32,
            anchor=tk.E,
            style="Status.TLabel",
        ).pack(side=tk.LEFT, padx=(14, 0))
        self.stop_button = ttk.Button(
            progress_card,
            text="Stop analysis",
            style="Danger.TButton",
            command=self._request_stop,
            state=tk.DISABLED,
        )
        self.stop_button.pack(side=tk.LEFT, padx=(12, 0))

        result_header = ttk.Frame(container)
        result_header.pack(fill=tk.X)
        ttk.Label(
            result_header,
            text="Analysis output",
            style="CardTitle.TLabel",
        ).pack(side=tk.LEFT)
        ttk.Label(
            result_header,
            text="The batch view keeps the three most recent results.",
            style="Subtitle.TLabel",
        ).pack(side=tk.RIGHT)

        self.output_text = self._make_code_area(container, height=18)
        self.output_text.pack(fill=tk.BOTH, expand=True, pady=(7, 0))

    def _load_existing_bytecode(self):
        if INPUT_BYTECODE_FILE.is_file():
            content = INPUT_BYTECODE_FILE.read_text(
                encoding="utf-8",
                errors="replace",
            ).strip()
            self.bytecode_text.insert("1.0", content)

    def _load_bytecode_file(self):
        filename = filedialog.askopenfilename(title="Select a bytecode file")
        if not filename:
            return
        content = Path(filename).read_text(
            encoding="utf-8",
            errors="replace",
        ).strip()
        self.bytecode_text.delete("1.0", tk.END)
        self.bytecode_text.insert("1.0", content)

    def _choose_input_folder(self):
        folder = filedialog.askdirectory(title="Select the input folder")
        if not folder:
            return
        selected_folder = Path(folder)
        nested_inputs = selected_folder / "inputs(wild contracts)"
        if nested_inputs.is_dir():
            selected_folder = nested_inputs
        self.batch_input_folder.set(str(selected_folder))
        self.batch_output_folder.set(
            str(selected_folder.parent / "outputs(extracted functions)")
        )

    def _choose_output_folder(self):
        folder = filedialog.askdirectory(title="Select the output folder")
        if folder:
            self.batch_output_folder.set(folder)

    @staticmethod
    def _normalize_bytecode(value):
        bytecode = "".join(value.split())
        if bytecode.lower().startswith("0x"):
            bytecode = bytecode[2:]
        if not bytecode:
            raise ValueError("Enter EVM bytecode before starting the analysis.")
        if not re.fullmatch(r"[0-9a-fA-F]+", bytecode):
            raise ValueError("Bytecode may contain hexadecimal characters only.")
        if len(bytecode) % 2:
            raise ValueError("Bytecode must contain an even number of hex characters.")
        return bytecode

    def _start_single_run(self):
        if self.process is not None:
            return
        try:
            bytecode = self._normalize_bytecode(
                self.bytecode_text.get("1.0", tk.END)
            )
        except ValueError as error:
            messagebox.showerror("Invalid input", str(error))
            return

        INPUT_BYTECODE_FILE.write_text(bytecode, encoding="utf-8")
        self.output_text.delete("1.0", tk.END)
        self._start_process(
            [sys.executable, "-u", str(SINGLE_RUNNER)],
            mode="single",
            total=1,
        )

    def _start_batch_run(self):
        if self.process is not None:
            return

        input_folder = Path(self.batch_input_folder.get().strip())
        output_value = self.batch_output_folder.get().strip()
        output_folder = Path(output_value) if output_value else None

        nested_inputs = input_folder / "inputs(wild contracts)"
        if nested_inputs.is_dir():
            input_folder = nested_inputs
            self.batch_input_folder.set(str(input_folder))
            if output_folder is None or output_folder == input_folder.parent:
                output_folder = (
                    input_folder.parent / "outputs(extracted functions)"
                )
                self.batch_output_folder.set(str(output_folder))

        if not input_folder.is_dir():
            messagebox.showerror("Invalid path", "Select a valid input folder.")
            return
        if output_folder is None:
            messagebox.showerror("Invalid path", "Select an output folder.")
            return

        files = [path for path in input_folder.iterdir() if path.is_file()]
        if not files:
            messagebox.showinfo("No inputs", "The selected folder contains no files.")
            return

        output_folder.mkdir(parents=True, exist_ok=True)
        self.recent_batch_results.clear()
        self.batch_statistics = None
        self.output_text.delete("1.0", tk.END)
        self._start_process(
            [
                sys.executable,
                "-u",
                str(BATCH_RUNNER),
                "--input-folder",
                str(input_folder),
                "--output-folder",
                str(output_folder),
                "--input-bytecode-file",
                str(INPUT_BYTECODE_FILE),
            ],
            mode="batch",
            total=len(files),
        )

    def _start_process(self, command, mode, total):
        self.run_mode = mode
        self.stop_requested = False
        self.progress.configure(maximum=max(total, 1), value=0)
        self.status_text.set("Starting analysis...")
        self.single_run_button.configure(state=tk.DISABLED)
        self.batch_run_button.configure(state=tk.DISABLED)
        self.stop_button.configure(state=tk.NORMAL)

        def worker():
            try:
                creation_flags = 0
                if sys.platform == "win32":
                    creation_flags = (
                        subprocess.CREATE_NO_WINDOW
                        | subprocess.CREATE_NEW_PROCESS_GROUP
                    )
                self.process = subprocess.Popen(
                    command,
                    cwd=PROJECT_DIR,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    encoding="utf-8",
                    errors="replace",
                    bufsize=1,
                    creationflags=creation_flags,
                    start_new_session=sys.platform != "win32",
                )
                if self.stop_requested:
                    self._terminate_process_tree(self.process)
                for line in self.process.stdout:
                    self.events.put(("line", line.rstrip()))
                return_code = self.process.wait()
                self.events.put(("done", return_code))
            except Exception as error:
                self.events.put(("failed", str(error)))

        threading.Thread(target=worker, daemon=True).start()

    def _request_stop(self):
        if self.run_mode is None:
            return
        self.stop_requested = True
        self.stop_button.configure(state=tk.DISABLED)
        self.status_text.set("Stopping analysis...")
        self.output_text.insert(tk.END, "\nStop requested by user.\n")
        self.output_text.see(tk.END)

        if self.process is not None:
            threading.Thread(
                target=self._terminate_process_tree,
                args=(self.process,),
                daemon=True,
            ).start()

    @staticmethod
    def _terminate_process_tree(process):
        if process.poll() is not None:
            return
        try:
            if sys.platform == "win32":
                subprocess.run(
                    [
                        "taskkill",
                        "/PID",
                        str(process.pid),
                        "/T",
                        "/F",
                    ],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    check=False,
                )
            else:
                os.killpg(os.getpgid(process.pid), signal.SIGTERM)
        except (OSError, ProcessLookupError):
            pass

        try:
            process.wait(timeout=2)
            return
        except subprocess.TimeoutExpired:
            pass

        try:
            if sys.platform == "win32":
                process.kill()
            else:
                os.killpg(os.getpgid(process.pid), signal.SIGKILL)
        except (OSError, ProcessLookupError):
            try:
                process.kill()
            except OSError:
                pass

    def _poll_events(self):
        try:
            while True:
                event, value = self.events.get_nowait()
                if event == "line":
                    self._handle_process_line(value)
                elif event == "done":
                    self._handle_process_done(value)
                elif event == "failed":
                    self._handle_process_failure(value)
        except queue.Empty:
            pass
        self.root.after(100, self._poll_events)

    def _handle_process_line(self, line):
        progress_match = re.match(
            r"^\[PROGRESS\]\s+(\d+)/(\d+)\s+(\w+)\s+(.+)$",
            line,
        )
        if progress_match:
            current, total, status, filename = progress_match.groups()
            self.progress.configure(maximum=int(total), value=int(current))
            self.status_text.set(
                f"{current}/{total} | {filename} | {status}"
            )
            return

        if line.startswith("[RESULT] "):
            self._show_recent_batch_result(Path(line[9:].strip()))
            return

        if line.startswith("[STATISTICS] "):
            self._show_statistics(Path(line[13:].strip()))
            return

        if line.startswith("[COMPLETE] "):
            self.status_text.set("Batch analysis complete")
            return

        if line:
            self.output_text.insert(tk.END, line + "\n")
            self.output_text.see(tk.END)

    def _show_recent_batch_result(self, result_file):
        try:
            content = result_file.read_text(
                encoding="utf-8",
                errors="replace",
            )
        except OSError as error:
            content = f"Unable to read {result_file}: {error}"

        maximum_characters = 14000
        if len(content) > maximum_characters:
            content = (
                content[:maximum_characters]
                + "\n\n... Preview truncated. The complete result is saved on disk."
            )
        self.recent_batch_results.appendleft(
            f"File: {result_file}\n{'-' * 70}\n{content}"
        )
        self._refresh_batch_output()

    def _show_statistics(self, statistics_file):
        try:
            self.batch_statistics = statistics_file.read_text(
                encoding="utf-8",
                errors="replace",
            ).strip()
        except OSError as error:
            self.batch_statistics = (
                f"Unable to read statistics from {statistics_file}: {error}"
            )
        self._refresh_batch_output()

    def _refresh_batch_output(self):
        sections = []
        if self.batch_statistics:
            sections.append(
                "Batch statistics\n"
                + "=" * 70
                + "\n"
                + self.batch_statistics
            )
        sections.extend(self.recent_batch_results)
        self.output_text.delete("1.0", tk.END)
        self.output_text.insert(
            "1.0",
            "\n\n".join(sections),
        )

    def _handle_process_done(self, return_code):
        mode = self.run_mode
        was_stopped = self.stop_requested
        self.process = None
        self.run_mode = None
        self.stop_requested = False
        self.single_run_button.configure(state=tk.NORMAL)
        self.batch_run_button.configure(state=tk.NORMAL)
        self.stop_button.configure(state=tk.DISABLED)

        if was_stopped:
            self.status_text.set("Analysis stopped by user")
            self.output_text.insert(
                tk.END,
                "\nAnalysis stopped. Completed result files remain available.\n",
            )
            self.output_text.see(tk.END)
            messagebox.showinfo(
                "Analysis stopped",
                "The analysis process and its child processes were stopped.",
            )
            return

        if mode == "single" and return_code == 0:
            self.progress.configure(value=1)
            self.status_text.set("Single analysis complete")
            try:
                content = SINGLE_FINAL_FILE.read_text(
                    encoding="utf-8",
                    errors="replace",
                )
                self.output_text.delete("1.0", tk.END)
                self.output_text.insert("1.0", content)
            except OSError as error:
                self._handle_process_failure(str(error))
                return
            messagebox.showinfo(
                "Analysis complete",
                "The single analysis result has been displayed and saved.",
            )
        elif mode == "batch":
            self.progress.configure(value=self.progress.cget("maximum"))
            if return_code == 0:
                self.status_text.set("Batch analysis complete")
                messagebox.showinfo(
                    "Analysis complete",
                    "All batch inputs have been processed.",
                )
            else:
                self.status_text.set("Batch complete with errors")
                messagebox.showwarning(
                    "Batch analysis complete",
                    "Processing finished, but some files failed. Review the output panel.",
                )
        else:
            self.status_text.set(f"Analysis failed (exit code {return_code})")
            messagebox.showerror(
                "Analysis failed",
                f"The analysis process exited with code {return_code}.",
            )

    def _handle_process_failure(self, error):
        self.process = None
        self.run_mode = None
        self.stop_requested = False
        self.single_run_button.configure(state=tk.NORMAL)
        self.batch_run_button.configure(state=tk.NORMAL)
        self.stop_button.configure(state=tk.DISABLED)
        self.status_text.set("Unable to start analysis")
        self.output_text.insert(tk.END, f"\nERROR: {error}\n")
        messagebox.showerror("Analysis failed", error)


def main():
    root = tk.Tk()
    ReFunGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
