
import concurrent.futures
import path_through_function
import function_signature_hash_extractor

class OverapproximateCallReturnSitePairings(object):
    def __init__(self, asm_file):
        self.asm_file = asm_file
        self.blocks = self.read_file(asm_file)   # a dictionary

    def read_file(self, asm_file):

        result = {}
        with open(asm_file, 'r') as f:
            paragraphs = f.read().split('\n\n')
            for p in paragraphs:
                lines = p.split('\n')
                index = None
                elements = []
                found_first_line = False
                for line in lines:
                    if line.strip() != "":
                        if not found_first_line:
                            index = line.strip()
                            found_first_line = True
                        else:
                            elements.append(line.split())
                if found_first_line:
                    result[index] = elements
        return result  
    
    def get_all_instruction_address(self):

        address = set()
        for value in self.blocks.values():
            for each_line in value:
                address.add(each_line[0])
        return address
    
    def get_all_likely_call_site(self):
        likely_call_site = []
        for key, value in self.blocks.items():
            address_counter = 0
            for each_line in value:
                if len(each_line) > 2 and 'PUSH' in each_line[1] and each_line[2] in self.get_all_instruction_address():
                    address_counter += 1
                if address_counter > 1 and 'JUMP' in value[-1][-1]:
                    likely_call_site.append(key)
                    break
        return likely_call_site
    
    def get_all_likely_return_site(self):
        likely_return_site = []
        for key, value in self.blocks.items():
            if (len(value) > 1 and len(value[-2]) <= 2 and value[-1][-1] == 'JUMP') or \
               (len(value) == 1 and value[-1][-1] == 'JUMP'):
                likely_return_site.append(key)
        return likely_return_site
    
    def get_likely_CR_pair_in_path(self, path):

        path_dict = {block: i for i, block in enumerate(path)}
        likely_call_return_site_pair = []
        address_of_likely_call_return_site = []


        for each_likely_return_site in self.get_all_likely_return_site():
            if each_likely_return_site in path_dict:
                index = path_dict[each_likely_return_site]
                if index + 1 < len(path):
                    jump_target_block = path[index + 1]
                    jump_target_address = self.blocks[jump_target_block][0][0]
                    address_of_likely_call_return_site.append([jump_target_address, each_likely_return_site])
        

        for each_pair in address_of_likely_call_return_site:
            for key, value in self.blocks.items():
                for each_line in value:
                    if len(each_line) == 3 and 'PUSH' in each_line[1] and each_pair[0] == each_line[2] and 'JUMP' in self.blocks[key][-1][-1]:
                        CR_pair = [key, each_pair[1]]
                        likely_call_return_site_pair.append(CR_pair)


        likely_call_return_site_pair = [pair for pair in likely_call_return_site_pair if pair[0] in path and pair[1] in path]
        return likely_call_return_site_pair
    
    def get_all_likely_CR_site_pair(self):
        get_function_path_class = path_through_function.PathThroughFunction(self.asm_file)
        get_function_signature = function_signature_hash_extractor.FunctionSignatureHashExtractor(self.asm_file).extract_function_signatures()
        

        function_path_set = {}
        with concurrent.futures.ThreadPoolExecutor() as executor:
            function_paths = list(executor.map(lambda signature: get_function_path_class.TFPath(signature), get_function_signature))
        
        for signature, function_path in zip(get_function_signature, function_paths):
            formal_value = self.get_likely_CR_pair_in_path(function_path)
            function_path.insert(0, signature)
            formal_key = tuple(function_path)
            function_path_set[formal_key] = formal_value
        
        return function_path_set


if __name__ == '__main__':
    asm_file = 'disassembly_result.txt'
    c = OverapproximateCallReturnSitePairings(asm_file)
    print(c.get_all_likely_CR_site_pair())



        
            
        

    
