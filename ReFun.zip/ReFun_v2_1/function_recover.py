
import joblib
import pandas as pd
from pathlib import Path
from sl import saz
from likely_CR_site_pairings_analyzer import OverapproximateCallReturnSitePairings

class SingleCalledFunctionRecover(object):
    def __init__(self):
        self.single_called_function = {}
        self.hint_list = {}
        model_file = Path(__file__).resolve().parent / 'random_forest_model.pkl'
        self.model = joblib.load(model_file)      
    def analyze_hints(self):
        get_path_and_pair = OverapproximateCallReturnSitePairings(asm_file='disassembly_result.txt').get_all_likely_CR_site_pair()
        
        for path, likely_CR_pair in get_path_and_pair.items():
            for each_pair in likely_CR_pair:
                hint_list = saz(list(path[1:]), each_pair[0], each_pair[-1]).sbb()
                

                if hint_list[3] == 'YES' and hint_list[4] == 'YES' and hint_list[5] == 'YES' \
                        and hint_list[6] == 'YES' and hint_list[8] == 'YES' and hint_list[9] == 'YES' \
                        and hint_list[10] == 'YES':
                    

                    features_for_prediction = {
                        'argument(stack_heigh_change)': hint_list[0],
                        'return(stack_heigh_change)': hint_list[1],
                        'jump_distance': hint_list[2],
                        'variable_gap': hint_list[7],
                        'sensitive_ops': hint_list[11],
                        '\u53c2\u6570\u6570\u91cf': hint_list[12],
                    }
               

                    prediction_input = pd.DataFrame([features_for_prediction])
                    prediction = self.model.predict(prediction_input)
                    

                    if prediction[0] == 1:
                        if f"inter_fun called by {path[0]}" not in self.single_called_function:
                            self.single_called_function[f"inter_fun called by {path[0]}"] = []
                        self.single_called_function[f"inter_fun called by {path[0]}"].append(each_pair)
                        self.hint_list[tuple(each_pair)] = [hint_list[i] for i in [0, 1, 2, 7, 11, 12]]

        return self.single_called_function, self.hint_list, len(self.single_called_function)


