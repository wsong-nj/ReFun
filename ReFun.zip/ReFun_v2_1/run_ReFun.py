#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Run ReFun once for the bytecode stored in ``input_bytecode``."""

import os
import re
import subprocess
import sys
import tempfile
import time
from pathlib import Path

from function_block_extractor import generate_final_output


PROJECT_DIR = Path(__file__).resolve().parent
INPUT_FILE = PROJECT_DIR / "input_bytecode"
DISASSEMBLY_FILE = PROJECT_DIR / "disassembly_result.txt"
LEGACY_OUTPUT_FILE = PROJECT_DIR / "output_functions"
FINAL_OUTPUT_FILE = PROJECT_DIR / "output_functions_final"


def validate_input_bytecode():
    if not INPUT_FILE.is_file():
        raise FileNotFoundError(f"Input file not found: {INPUT_FILE}")

    bytecode = INPUT_FILE.read_text(encoding="utf-8").strip()
    if not bytecode:
        raise ValueError("input_bytecode is empty")
    if not re.fullmatch(r"[0-9a-fA-F]+", bytecode):
        raise ValueError(
            "input_bytecode must contain only hexadecimal bytecode, "
            "without labels, spaces, or a 0x prefix"
        )
    if len(bytecode) % 2 != 0:
        raise ValueError("input_bytecode must contain an even number of hex characters")


def analyze_functions():
    # Import only after validating the input so malformed input produces a
    # useful error even when optional analysis dependencies are unavailable.
    from function_restorer import FunctionRestorer

    class SingleRunFunctionRestorer(FunctionRestorer):
        """Use the current interpreter and fail if disassembly is unsuccessful."""

        def __init__(self):
            self.start_time = time.time()
            subprocess.run(
                [sys.executable, str(PROJECT_DIR / "disassembler.py")],
                cwd=PROJECT_DIR,
                check=True,
            )

    original_working_directory = Path.cwd()
    try:
        os.chdir(PROJECT_DIR)
        return SingleRunFunctionRestorer().get_results_in_list()
    finally:
        os.chdir(original_working_directory)


def write_results(
    output_path,
    function_list,
    time_consumption,
    hint_list,
    function_count,
):
    disassembly_content = DISASSEMBLY_FILE.read_text(encoding="utf-8")

    with Path(output_path).open("w", encoding="utf-8") as output_file:
        for function in function_list:
            output_file.write(function + "\n")

        output_file.write("\n" + time_consumption + "\n")
        output_file.write(f"\nFunction count: {function_count}\n")
        output_file.write("\n" + "*" * 50 + "\n")
        output_file.write(disassembly_content)
        output_file.write("\n" + "#" * 50 + "\n")
        output_file.write(str(hint_list))


def main():
    validate_input_bytecode()

    function_list, time_consumption, hint_list, function_count = (
        analyze_functions()
    )
    with tempfile.TemporaryDirectory(prefix="refun_single_") as temporary_directory:
        intermediate_file = Path(temporary_directory) / "intermediate_result.txt"
        write_results(
            intermediate_file,
            function_list,
            time_consumption,
            hint_list,
            function_count,
        )
        final_summary = generate_final_output(
            intermediate_file,
            FINAL_OUTPUT_FILE,
            source_name=INPUT_FILE.name,
        )

    if LEGACY_OUTPUT_FILE.is_file():
        LEGACY_OUTPUT_FILE.unlink()

    print(f"Analysis complete. Found {function_count} functions.")
    print(
        "Final result written to: "
        f"{final_summary['final_file']} "
        f"({final_summary['public_function_count']} public, "
        f"{final_summary['private_function_count']} private)"
    )
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (ImportError, OSError, ValueError, subprocess.CalledProcessError) as error:
        print(f"Analysis failed: {error}", file=sys.stderr)
        sys.exit(1)
