#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Summarize function-extraction results produced by the batch runner."""

import argparse
import re
from pathlib import Path


PROJECT_DIR = Path(__file__).resolve().parent
PRIVATE_MARKERS = ("0x2266", "0x260")
PUBLIC_TERMINAL_OPCODES = {
    "RETURN",
    "STOP",
    "REVERT",
    "SELFDESTRUCT",
    "INVALID",
}
FINAL_RESULT_HEADER = "REFUN FINAL FUNCTION BASIC BLOCKS"


def _public_extraction_reaches_terminal(section):
    if not re.search(r"(?m)^STATUS complete\s*$", section):
        return False
    if "BEGIN_BLOCKS" not in section:
        return False

    block_content = section.split("BEGIN_BLOCKS", 1)[1]
    instructions = []
    for line in block_content.splitlines():
        columns = line.split()
        if len(columns) >= 2 and columns[0].startswith("0x"):
            instructions.append(columns[1])
    return (
        bool(instructions)
        and instructions[-1] in PUBLIC_TERMINAL_OPCODES
    )


def _parse_final_result(result_file):
    """Return total and evidence-backed correct extractions in one result."""
    content = Path(result_file).read_text(encoding="utf-8", errors="replace")
    extracted_function_count = 0
    correctly_extracted_function_count = 0
    function_sections = re.finditer(
        r"(?ms)^FUNCTION\s+(public|private)\s+.*?^END_FUNCTION\s*$",
        content,
    )
    for match in function_sections:
        extracted_function_count += 1
        function_type = match.group(1)
        section = match.group(0)
        if function_type == "public":
            if _public_extraction_reaches_terminal(section):
                correctly_extracted_function_count += 1
        else:
            block_content = (
                section.split("BEGIN_BLOCKS", 1)[1]
                if "BEGIN_BLOCKS" in section
                else section
            )
            if any(marker in block_content for marker in PRIVATE_MARKERS):
                correctly_extracted_function_count += 1

    return extracted_function_count, correctly_extracted_function_count


def _parse_elapsed_time(result_file):
    content = Path(result_file).read_text(encoding="utf-8", errors="replace")
    match = re.search(
        r"(?m)^ANALYSIS_TIME_SECONDS\s+([0-9]+(?:\.[0-9]+)?)\s*$",
        content,
    )
    return float(match.group(1)) if match else None


def _find_final_result_files(output_folder):
    final_files = []
    for result_file in sorted(Path(output_folder).glob("*.txt")):
        if result_file.name == "result_statistics.txt":
            continue
        try:
            with result_file.open(
                "r",
                encoding="utf-8",
                errors="replace",
            ) as stream:
                first_line = stream.readline().strip()
        except OSError:
            continue
        if first_line == FINAL_RESULT_HEADER:
            final_files.append(result_file)
    return final_files


def collect_statistics(output_folder):
    output_folder = Path(output_folder).resolve()
    if not output_folder.is_dir():
        raise NotADirectoryError(f"Output folder not found: {output_folder}")

    final_files = _find_final_result_files(output_folder)

    extracted_function_count = 0
    correctly_extracted_function_count = 0
    elapsed_times = []
    for result_file in final_files:
        extracted, correctly_extracted = _parse_final_result(result_file)
        extracted_function_count += extracted
        correctly_extracted_function_count += correctly_extracted
        elapsed_time = _parse_elapsed_time(result_file)
        if elapsed_time is not None:
            elapsed_times.append(elapsed_time)

    extraction_precision = (
        correctly_extracted_function_count
        / extracted_function_count
        * 100
        if extracted_function_count
        else None
    )
    average_time = (
        sum(elapsed_times) / len(elapsed_times)
        if elapsed_times
        else 0.0
    )
    return {
        "result_file_count": len(final_files),
        "extracted_function_count": extracted_function_count,
        "correctly_extracted_function_count": (
            correctly_extracted_function_count
        ),
        "function_extraction_precision_percent": extraction_precision,
        "timed_result_count": len(elapsed_times),
        "average_time_seconds": average_time,
    }


def format_statistics(statistics):
    extraction_precision = (
        f"{statistics['function_extraction_precision_percent']:.2f}%"
        if statistics["function_extraction_precision_percent"] is not None
        else "N/A (no extracted functions)"
    )

    return "\n".join(
        [
            "REFUN FUNCTION EXTRACTION STATISTICS",
            "=" * 40,
            f"Result files: {statistics['result_file_count']}",
            "Extracted functions: "
            f"{statistics['extracted_function_count']}",
            "Correctly extracted functions: "
            f"{statistics['correctly_extracted_function_count']}",
            f"Function-extraction precision: {extraction_precision}",
            f"Results with timing data: {statistics['timed_result_count']}",
            f"Average analysis time: {statistics['average_time_seconds']:.2f} seconds",
        ]
    )


def write_statistics(
    output_folder,
    statistics_file=None,
):
    output_folder = Path(output_folder).resolve()
    statistics = collect_statistics(output_folder)
    statistics_file = (
        Path(statistics_file).resolve()
        if statistics_file is not None
        else output_folder / "result_statistics.txt"
    )
    statistics_file.parent.mkdir(parents=True, exist_ok=True)
    statistics_file.write_text(
        format_statistics(statistics) + "\n",
        encoding="utf-8",
    )
    return statistics, statistics_file


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="Summarize ReFun batch results"
    )
    parser.add_argument(
        "--output-folder",
        default=str(PROJECT_DIR / "outputs(extracted functions)"),
    )
    parser.add_argument("--statistics-file")
    arguments = parser.parse_args(argv)

    statistics, statistics_file = write_statistics(
        arguments.output_folder,
        arguments.statistics_file,
    )
    print(format_statistics(statistics))
    print(f"Statistics written to: {statistics_file}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
