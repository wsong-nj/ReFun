#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Build the final per-function basic-block output from a ReFun result file."""

import re
import tempfile
from pathlib import Path

from function_signature_hash_extractor import FunctionSignatureHashExtractor
from path_through_function import PathThroughFunction


SECTION_SEPARATOR = "*" * 50
HINT_SEPARATOR = "#" * 50


def _split_intermediate_output(content):
    try:
        prefix, remainder = content.split(SECTION_SEPARATOR, 1)
        disassembly, hints = remainder.split(HINT_SEPARATOR, 1)
    except ValueError as error:
        raise ValueError(
            "The intermediate result does not contain the expected separators"
        ) from error

    return prefix.strip(), disassembly.strip(), hints.strip()


def _parse_private_function_pairs(prefix):
    block_ids = re.findall(r"(?m)^\s*(block_\d+)\s*$", prefix)
    count_match = re.search(r"Function count\s*:\s*(\d+)", prefix)
    if count_match is None:
        legacy_count_label = "\u51fd\u6570\u4e2a\u6570"
        count_match = re.search(
            legacy_count_label + r"\s*[\uff1a:]\s*(\d+)",
            prefix,
        )

    if not block_ids:
        return []

    if count_match:
        function_count = int(count_match.group(1))
        if function_count <= len(block_ids) <= function_count * 2:
            paired_function_count = len(block_ids) - function_count
            paired_block_count = paired_function_count * 2
            pairs = [
                (block_ids[index], block_ids[index + 1])
                for index in range(0, paired_block_count, 2)
            ]
            pairs.extend(
                (block_id, block_id)
                for block_id in block_ids[paired_block_count:]
            )
            return pairs

    pairs = []
    for index in range(0, len(block_ids), 2):
        start_block = block_ids[index]
        end_block = (
            block_ids[index + 1]
            if index + 1 < len(block_ids)
            else start_block
        )
        pairs.append((start_block, end_block))
    return pairs


def _parse_elapsed_time(prefix):
    match = re.search(
        r"Elapsed time\s*:\s*([0-9]+(?:\.[0-9]+)?)\s*seconds?",
        prefix,
        flags=re.IGNORECASE,
    )
    if match is None:
        legacy_label = "\u65f6\u95f4\u6d88\u8017"
        match = re.search(
            legacy_label
            + r"\s*[\uff1a:]\s*([0-9]+(?:\.[0-9]+)?)\s*"
            + "\u79d2",
            prefix,
        )
    return float(match.group(1)) if match else None


def _raw_blocks(disassembly):
    blocks = {}
    paragraphs = re.split(r"\r?\n\s*\r?\n", disassembly.strip())
    for paragraph in paragraphs:
        lines = paragraph.strip().splitlines()
        if lines and re.fullmatch(r"block_\d+", lines[0].strip()):
            blocks[lines[0].strip()] = "\n".join(lines)
    return blocks


def _unique_path(path):
    return list(dict.fromkeys(block for block in path if block is not None))


def _render_function(
    function_type,
    function_id,
    path,
    raw_blocks,
    expected_end=None,
    error=None,
):
    unique_blocks = _unique_path(path)
    reached_end = expected_end is None or expected_end in path

    lines = [
        f"FUNCTION {function_type} {function_id}",
        f"ENTRY {path[0] if path else 'UNKNOWN'}",
        f"END {expected_end or (path[-1] if path else 'UNKNOWN')}",
        f"STATUS {'complete' if reached_end and error is None else 'partial'}",
        "PATH " + " -> ".join(path),
    ]
    if error is not None:
        lines.append(f"ERROR {error}")
    lines.append("BEGIN_BLOCKS")

    for block_id in unique_blocks:
        lines.append("")
        lines.append(raw_blocks.get(block_id, f"{block_id}\n<block not found>"))

    lines.extend(["", "END_FUNCTION"])
    return "\n".join(lines)


def generate_final_output(intermediate_file, final_file, source_name=None):
    intermediate_file = Path(intermediate_file)
    final_file = Path(final_file)
    content = intermediate_file.read_text(encoding="utf-8")
    prefix, disassembly, _ = _split_intermediate_output(content)
    private_pairs = _parse_private_function_pairs(prefix)
    elapsed_time = _parse_elapsed_time(prefix)
    raw_blocks = _raw_blocks(disassembly)

    public_functions = []
    private_functions = []

    with tempfile.TemporaryDirectory(prefix="refun_blocks_") as temporary_directory:
        asm_file = Path(temporary_directory) / "disassembly_result.txt"
        asm_file.write_text(disassembly + "\n", encoding="utf-8")

        path_extractor = PathThroughFunction(str(asm_file))
        selectors = FunctionSignatureHashExtractor(
            str(asm_file)
        ).extract_function_signatures()

        for selector in selectors:
            try:
                path = path_extractor.TFPath(selector)
                public_functions.append(
                    _render_function(
                        "public",
                        selector,
                        path,
                        raw_blocks,
                    )
                )
            except Exception as error:
                start_block = path_extractor.find_start_block(selector, str(asm_file))
                fallback_path = [start_block] if start_block else []
                public_functions.append(
                    _render_function(
                        "public",
                        selector,
                        fallback_path,
                        raw_blocks,
                        error=str(error),
                    )
                )

        for index, (start_block, end_block) in enumerate(private_pairs, start=1):
            try:
                path = path_extractor.path_between_blocks(start_block, end_block)
                private_functions.append(
                    _render_function(
                        "private",
                        f"private_{index}",
                        path,
                        raw_blocks,
                        expected_end=end_block,
                    )
                )
            except Exception as error:
                fallback_path = list(
                    dict.fromkeys((start_block, end_block))
                )
                private_functions.append(
                    _render_function(
                        "private",
                        f"private_{index}",
                        fallback_path,
                        raw_blocks,
                        expected_end=end_block,
                        error=str(error),
                    )
                )

    header = [
        "REFUN FINAL FUNCTION BASIC BLOCKS",
        f"SOURCE {source_name or intermediate_file.name}",
        f"PUBLIC_FUNCTIONS {len(public_functions)}",
        f"PRIVATE_FUNCTIONS {len(private_functions)}",
    ]
    if elapsed_time is not None:
        header.append(f"ANALYSIS_TIME_SECONDS {elapsed_time:.2f}")
    header.append("=" * 70)
    sections = public_functions + private_functions
    output = "\n".join(header)
    if sections:
        output += "\n\n" + "\n\n".join(sections)
    output += "\n"
    final_file.parent.mkdir(parents=True, exist_ok=True)
    final_file.write_text(output, encoding="utf-8")

    return {
        "public_function_count": len(public_functions),
        "private_function_count": len(private_functions),
        "final_file": str(final_file),
    }


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description="Extract each function's basic blocks from a ReFun result"
    )
    parser.add_argument("intermediate_file")
    parser.add_argument("final_file")
    arguments = parser.parse_args()

    summary = generate_final_output(
        arguments.intermediate_file,
        arguments.final_file,
    )
    print(
        "Generated "
        f"{summary['public_function_count']} public and "
        f"{summary['private_function_count']} private functions: "
        f"{summary['final_file']}"
    )
