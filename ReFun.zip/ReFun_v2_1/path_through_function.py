

import EVM_for_path_exploration
from function_signature_hash_extractor import FunctionSignatureHashExtractor

class PathThroughFunction(object):
    def __init__(self, asm_file):
        self.asm_file = asm_file
        self.blocks = self.read_file(asm_file)

        
        
    def read_file(self, asm_file):
        with open(asm_file, 'r') as f:
            content = f.read()

        paragraphs = content.split('\n\n')
        result = {}

        for p in paragraphs:
            lines = p.split('\n')
            index = None
            elements = []
            found_first_line = False

            for line in lines:
                if line.strip() != "":
                    if not found_first_line:
                        index = line.strip()
                        found_first_line = True
                    else:
                        elements.append(line.split())

            if found_first_line:
                result[index] = elements

        return result        
        
    

    def find_start_block(self, signature_hash, asm_file):
        with open(asm_file, 'r') as f:
            lines = f.readlines()
            start_index = -1

            for i in range(len(lines)): 
                if str(signature_hash) in lines[i] and ('EQ' in lines[i+1] or 'EQ' in lines[i+2]):
                    start_index = i
                    break
                if start_index != -1: 
                    break
            if start_index == -1:
                print("Start block not found in the ASM file.")
                return None

            for j in range(start_index, len(lines)):
                line = lines[j].split()
                if len(line) == 3:
                    index = line[-1]
                    for k in range(j + 1, len(lines)):
                        if lines[k].startswith(index):
                            return lines[k-1].split()[0]

            print("Start block not found in the ASM file.")
            return None


    def TFPath(self, signature_hash):
        start_block = self.find_start_block(signature_hash, self.asm_file)
        return self.path_from_block(start_block)


    def path_between_blocks(self, start_block, end_block):

        initial_stack = [f"caller_stack_{index}" for index in range(64)]
        return self.path_from_block(start_block, end_block, initial_stack)


    def path_from_block(self, start_block, end_block=None, initial_stack=None):
        function_path = []
        function_path.append(start_block)
        evm = EVM_for_path_exploration.EVM()
        for value in initial_stack or []:
            evm.stack.push(value)
        execute_block_number = start_block

        sign = ''
        stack = []
        visited_states = set()
        steps = 0
        max_steps = max(1000, len(self.blocks) * 10)
        terminal_opcodes = ('RETURN', 'STOP', 'SELFDESTRUCT', 'REVERT', 'INVALID')
        while sign not in terminal_opcodes:
            if end_block is not None and execute_block_number == end_block:
                break

            current_block_number = execute_block_number
            current_state = (execute_block_number, tuple(evm.stack))


            if current_state in visited_states or steps >= max_steps:
                break
            visited_states.add(current_state)
            steps += 1

            if ((self.blocks[execute_block_number][-1][1] == 'JUMP') and 
                ('AND' not in self.blocks[execute_block_number][-2][1])):        #normal jump

                for codeline in self.blocks[execute_block_number][:-1]:

                    if len(codeline) > 2:
 
                        stack = evm.execute(codeline[1], codeline[2])['stack']

                    else:

                        stack = evm.execute(codeline[1])['stack']
                
                        
                try:
                    next_block_index = stack[-1]
                except IndexError:
                    print("Error: The stack is empty.") 
               
                stack = evm.execute('JUMP')['stack']
          
                for key, value in self.blocks.items():
                    first_item_for_sure = 0
                    for sub_value in value[0]:
                        first_item_for_sure += 1
                        if next_block_index == sub_value and first_item_for_sure == 1 :
                            execute_block_number = key
                        
                            if execute_block_number != 'block_0':
                                function_path.append(execute_block_number)
                        
                        
            elif (self.blocks[execute_block_number][-1][1] == 'JUMP' and     # wash jump
                self.blocks[execute_block_number][-2][1] == 'AND' and
                'PUSH' in self.blocks[execute_block_number][-3][1] and
                'PUSH' in self.blocks[execute_block_number][-4][1] and
                '0xff' in self.blocks[execute_block_number][-4][2]):
               

                block = self.blocks[execute_block_number]
                ignored_indexes = (len(block) - 4, len(block) - 2)
                executable_block = [
                    codeline for index, codeline in enumerate(block)
                    if index not in ignored_indexes
                ]
                for codeline in executable_block[:-1]:
                    if len(codeline) > 2:
                        stack = evm.execute(codeline[1], codeline[2])['stack']
                    else:
                        stack = evm.execute(codeline[1])['stack']
                                        
                try:
                    next_block_index = stack[-1]
                except IndexError:
                    print("Error: The stack is empty.") 
             
                stack = evm.execute('JUMP')['stack']
          
                for key, value in self.blocks.items():
                    first_item_for_sure = 0
                    for sub_value in value[0]:
                        first_item_for_sure += 1
                        if next_block_index == sub_value and first_item_for_sure == 1 :
                            execute_block_number = key
                            if execute_block_number != 'block_0':
                                function_path.append(execute_block_number)
                                                            

                            

            elif self.blocks[execute_block_number][-1][1] == 'JUMPI':

                for codeline in self.blocks[execute_block_number][:-1]:
                    if len(codeline) > 2:
                 
                        stack = evm.execute(codeline[1], codeline[2])['stack']
                    
                    else:
               
                        stack = evm.execute(codeline[1])['stack']
                 
                try:
                    next_block_index = stack[-1]
                except IndexError:
                    print("Error: The stack is empty.")

                stack = evm.execute('JUMPI')['stack']  

                for key, value in self.blocks.items():
                    first_item_for_sure = 0
                    for sub_value in value[0]:
                        first_item_for_sure += 1
                        if first_item_for_sure == 1 and next_block_index == sub_value and 'REVERT' not in self.blocks[key][-1][1]:
                            execute_block_number = key
                            function_path.append(execute_block_number)
                        elif first_item_for_sure == 1 and next_block_index == sub_value and 'REVERT' in self.blocks[key][-1][1]:
                            block_list = list(self.blocks.keys())
                            execute_block_index = block_list.index(execute_block_number)
                            execute_block_number = block_list[execute_block_index+1]
                            function_path.append(execute_block_number)

                            

            elif self.blocks[execute_block_number][-1][1] not in ['REVERT', 'INVALID', 'JUMP', 'JUMPI']:

                for codeline in self.blocks[execute_block_number]:
                    if len(codeline) > 2:

                        evm.execute(codeline[1], codeline[2])['stack']
                    else:

                        evm.execute(codeline[1])['stack']
                block_list = list(self.blocks.keys())
                execute_block_index = block_list.index(execute_block_number)
                execute_block_number = block_list[execute_block_index+1]
                function_path.append(execute_block_number)

                
            
                                            
            sign = self.blocks[execute_block_number][-1][1]


            if execute_block_number == current_block_number and sign not in terminal_opcodes:
                break
            

        return function_path


if __name__ == '__main__':
    
    asm_file = 'disassembly_result.txt'
    fshe = FunctionSignatureHashExtractor(asm_file)
    signatures_hash = fshe.extract_function_signatures()
    
    cfg = PathThroughFunction(asm_file)

    function_path = cfg.TFPath(signatures_hash[1])

    print(function_path)
    print(len(function_path))
    print(signatures_hash[1])
