
from disassembler import Disassembler
from likely_CR_site_pairings_analyzer import OverapproximateCallReturnSitePairings
from get_blocks_appears_in_multiple_functions import GetBlocksApperaInMultipleFunctions
from collections import defaultdict



class MultipleCalledFunctionRecover(object):
    def __init__(self):
        self.asm_file = 'disassembly_result.txt'
        self.blocks = self.read_file(self.asm_file)   # a dictionary
        self.blocks_appear_in_multiple_function = GetBlocksApperaInMultipleFunctions(self.asm_file).get_blocks_and_functions_they_within()

    def read_file(self, asm_file):
        with open(asm_file, 'r') as f:
            content = f.read()
        paragraphs = content.split('\n\n')
        result = {}
        for p in paragraphs:
            lines = p.split('\n')
            index = None
            elements = []
            found_first_line = False
            for line in lines:
                if line.strip() != "":
                    if not found_first_line:
                        index = line.strip()
                        found_first_line = True
                    else:
                        elements.append(line.split())
            if found_first_line:
                result[index] = elements
        return result 
   
    def drop_transferring_block(self):
        transferring_cabinet = ['JUM', 'PUS', 'DUP', 'SWA', 'POP', 'ISZ', 'CALLDATALO', 'AND', 'EQ', 'REQ', 'MLO', 'ADD', 'MST', 'SUB', 'GT', 'LT']
        for key in list(self.blocks_appear_in_multiple_function.keys()):            
            for opcode in self.blocks[key]:
                if all(any(opcode[1].startswith(cabinet) for cabinet in transferring_cabinet) for opcode in self.blocks[key]):
                    self.blocks_appear_in_multiple_function.pop(key, None)
                    
        return self.blocks_appear_in_multiple_function
    
    def drop_state_variable_service_block(self): 

        function_path_CR_pair = OverapproximateCallReturnSitePairings(self.asm_file).get_all_likely_CR_site_pair()
        

        keys_to_remove = []
        
        for multiple_appeared_block in self.blocks_appear_in_multiple_function.keys():
            for function_path in function_path_CR_pair.keys():
                if multiple_appeared_block in function_path[:3]:
                    keys_to_remove.append(multiple_appeared_block)
                    break  
        
        for key in keys_to_remove:
            self.blocks_appear_in_multiple_function.pop(key, None)
        
        return self.blocks_appear_in_multiple_function
    
    
    def find_blocks_more_than_3_appeared_in_specific_functions(self, input_dict, min_occurrences=3):
        grouped_keys = defaultdict(list)
    
        for key, value in input_dict.items():
            sorted_value = tuple(sorted(value))  
            grouped_keys[sorted_value].append(key)
    
        result_keys = []
        for keys in grouped_keys.values():
            if len(keys) >= min_occurrences:  
                result_keys.append(keys)    
        return result_keys  
    
    def check_path_lengths(self, input_dict, query_list):
        lengths = []
        
        for key in input_dict.keys():
            if key[0] in query_list:
                lengths.append(len(key)) 
        

        return len(set(lengths)) == 1  
    
    
    def drop_private_state_variable_with_same_type_return_function(self):

        function_path_CR_pair = OverapproximateCallReturnSitePairings(self.asm_file).get_all_likely_CR_site_pair()
        blocks_to_remove = self.find_blocks_more_than_3_appeared_in_specific_functions(self.blocks_appear_in_multiple_function)
        real_to_remove = []

        for group in blocks_to_remove:
            if self.check_path_lengths(function_path_CR_pair, self.blocks_appear_in_multiple_function[group[0]]):
                real_to_remove.append(group)
                #print(real_to_remove)
                
        for item in real_to_remove:
            for key in item:
                self.blocks_appear_in_multiple_function.pop(key, None)
                
        return self.blocks_appear_in_multiple_function
    
    
    def drop_state_variable_cleaning(self):
        cleaning_cabinet = ['JUM', 'PUS', 'NOT', 'DUP', 'SWA', 'POP', 'AND', 'ADD']
        for key in list(self.blocks_appear_in_multiple_function.keys()):            
            for opcode in self.blocks[key]:
                if all(any(opcode[1].startswith(cabinet) for cabinet in cleaning_cabinet) for opcode in self.blocks[key]) and \
                any(len(opcode) > 2 and opcode[2] == '0x1f' for opcode in self.blocks[key]):
                    self.blocks_appear_in_multiple_function.pop(key, None)
                    
        return self.blocks_appear_in_multiple_function
    
    
    def rise_leave_then_come_back(self, blocks_after_drop):

        function_path_CR_pair = OverapproximateCallReturnSitePairings(self.asm_file).get_all_likely_CR_site_pair()
        def extract_number(block_name):
            if block_name is None:
                return None
            try:
                return int(block_name.split('_')[-1])
            except ValueError:
                return None
    
        internal_function_1 = {}
        for block, function in blocks_after_drop.items():
            for path in function_path_CR_pair.keys():
                if function[0] in path and block in path:

                    index = path.index(block)
                    #print(index)


                    prev_block = path[index - 1] if index > 0 else None
                    next_block = path[index + 1] if index < len(path) - 1 else None
                    

                    current_num = extract_number(block)
                    prev_num = extract_number(prev_block)
                    next_num = extract_number(next_block)

                    if prev_num is not None and next_num is not None:
                       
                        if prev_num + 1 == next_num:

                            internal_function_1[block] = blocks_after_drop[block]

                            break  
        return internal_function_1
    


    def find_longest_common_sublist(self, list1, list2, target_sublist):

        indices1 = [list1.index(x) for x in target_sublist if x in list1]
        indices2 = [list2.index(x) for x in target_sublist if x in list2]
    

        start1 = min(indices1)
        start2 = min(indices2)
        
        end1 = max(indices1)
        end2 = max(indices2)
    

        common_sublist = []
        i, j = start1, start2
        

        while i > 0 and j > 0 and list1[i - 1] == list2[j - 1]:
            i -= 1
            j -= 1
    

        while i <= len(list1) - 1 and j <= len(list2) - 1 and list1[i] == list2[j]:
            common_sublist.append(list1[i])
            i += 1
            j += 1
        
        return common_sublist



    
    def rise_continuous_blocks_that_appear_multiple_times(self, blocks_after_state_cleaning_drop):


        function_path_CR_pair = OverapproximateCallReturnSitePairings(self.asm_file).get_all_likely_CR_site_pair()
        internal_function_x = []
    

        grouped_keys = defaultdict(list)
        for key, value in blocks_after_state_cleaning_drop.items():
            grouped_keys[frozenset(value)].append(key)
    

        blocks_grouped_by_functions = [group for group in grouped_keys.values() if len(group) > 1]
    

        for group in blocks_grouped_by_functions:

            function_1 = blocks_after_state_cleaning_drop[group[0]][0]
            function_2 = blocks_after_state_cleaning_drop[group[0]][1]
    

            path_1, path_2 = None, None
            for key in function_path_CR_pair.keys():
                if function_1 == key[0]:
                    path_1 = key
                    break
    
            for key in function_path_CR_pair.keys():
                if function_2 == key[0]:
                    path_2 = key
                    break
    

            if path_1 is not None and path_2 is not None:
                longest_substring = self.find_longest_common_sublist(path_1, path_2, group)
                internal_function_x.append(longest_substring)
            else:
                print(f"Warning: Paths not found for functions {function_1} or {function_2}")
    
        return internal_function_x
    
    
    def get_functions(self):
        block_after_same_function_drop = self.drop_private_state_variable_with_same_type_return_function()
        blocks_after_transfer_drop = self.drop_transferring_block()
        blocks_after_state_var_drop = self.drop_state_variable_service_block()
        blocks_after_state_cleaning_drop = self.drop_state_variable_cleaning()
        
        internal_function_1 = self.rise_leave_then_come_back(blocks_after_state_cleaning_drop)
        internal_function_x = self.rise_continuous_blocks_that_appear_multiple_times(blocks_after_state_cleaning_drop)
        
        return internal_function_1, internal_function_x, len(internal_function_1), len(internal_function_x)
        
            
            
        

           


        

