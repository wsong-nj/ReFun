import os
import re


folder_A = r"inputs(wild contracts)"


def check_runtime_bytecode(file_path):


    try:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            lines = f.readlines()

    except Exception:
        return False, "read_error"



    if len(lines) == 0:
        return False, "empty"



    if len(lines) != 1:
        return False, "multiple_lines"


    content = lines[0].strip()



    if not content:
        return False, "empty"



    if content.lower().startswith("0x"):
        content = content[2:]



    if not re.fullmatch(r"[0-9a-fA-F]+", content):
        return False, "invalid_character"



    if len(content) % 2 != 0:
        return False, "odd_length"


    return True, "valid"



invalid_count = 0


for filename in os.listdir(folder_A):

    if not filename.endswith(".txt"):
        continue


    file_path = os.path.join(folder_A, filename)

    valid, reason = check_runtime_bytecode(file_path)


    if not valid:
        print(f"[INVALID] {filename}  ({reason})")
        invalid_count += 1



print("\nFinished.")
print("Invalid files:", invalid_count)
