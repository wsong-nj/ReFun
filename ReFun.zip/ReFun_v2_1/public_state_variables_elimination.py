

from likely_CR_site_pairings_analyzer import OverapproximateCallReturnSitePairings
class StateVariableElimination(object):
    def __init__(self, path, pair):
        self.path = path
        self.pair = pair

    def are_the_first_two_blocks(self):
        if self.pair[0] == self.path[0] and self.pair[-1] == self.path[1]:
            return 'NO'
        return 'YES'

            
