

from collections import Counter
import EVM_for_path_exploration
import path_through_function
import function_signature_hash_extractor

class GetBlocksApperaInMultipleFunctions(object):
    def __init__(self, asm_file):
        self.asm_file = asm_file
        self.blocks = self.read_file(asm_file)   # a dictionary

    def read_file(self, asm_file):
        with open(asm_file, 'r') as f:
            content = f.read()
        paragraphs = content.split('\n\n')
        result = {}
        for p in paragraphs:
            lines = p.split('\n')
            index = None
            elements = []
            found_first_line = False
            for line in lines:
                if line.strip() != "":
                    if not found_first_line:
                        index = line.strip()
                        found_first_line = True
                    else:
                        elements.append(line.split())
            if found_first_line:
                result[index] = elements
        return result 
        
    
    def get_blocks_and_functions_they_within(self):
        get_function_path_class = path_through_function.PathThroughFunction(self.asm_file)
        get_function_signature = function_signature_hash_extractor.FunctionSignatureHashExtractor(self.asm_file).extract_function_signatures()
        function_path_set = {}
        combined_path = []
        for signature in get_function_signature:
            function_path = get_function_path_class.TFPath(signature)
            #function_path_set.append(function_path) 
            function_path_set[signature] = function_path
        for each_path in function_path_set.values():
            combined_path = combined_path + each_path
            
        block_times = Counter(combined_path) 


        multiple_used_blocks = [elem for elem in combined_path if block_times[elem] > 1]
        block_in_multiple_functions = {}
        for block in multiple_used_blocks:
            block_in_multiple_functions[block] = []
            for each_signature, each_path in function_path_set.items():
                if block in each_path:
                    block_in_multiple_functions[block].append(each_signature)
        return block_in_multiple_functions
                    

            
                
        
        


