

import argparse
import os
import re
import sys
import tempfile
from pathlib import Path

from function_block_extractor import generate_final_output
from function_restorer import FunctionRestorer
from result_statistics import write_statistics


PROJECT_DIR = Path(__file__).resolve().parent


def read_input_bytecode(input_file):
    """Read raw bytecode or find a bytecode line in a dataset-style file."""
    content = Path(input_file).read_text(encoding="utf-8", errors="replace")
    for line in content.splitlines():
        candidate = line.strip()
        if candidate.lower().startswith("0x"):
            candidate = candidate[2:]
        if (
            candidate
            and len(candidate) % 2 == 0
            and re.fullmatch(r"[0-9a-fA-F]+", candidate)
        ):
            return candidate

    raise ValueError("no valid even-length hexadecimal bytecode line found")


def write_intermediate_result(
    output_file,
    function_list,
    time_consumption,
    hint_list,
    function_count,
):
    disassembly_file = PROJECT_DIR / "disassembly_result.txt"
    disassembly_content = disassembly_file.read_text(encoding="utf-8")

    with Path(output_file).open("w", encoding="utf-8") as stream:
        for function in function_list:
            stream.write(function + "\n")

        stream.write("\n" + time_consumption + "\n")
        stream.write(f"\nFunction count: {function_count}\n")
        stream.write("\n" + "*" * 50 + "\n")
        stream.write(disassembly_content)
        stream.write("\n" + "#" * 50 + "\n")
        stream.write(str(hint_list))


def process_file(
    input_file,
    result_folder,
    input_bytecode_file,
    delete_input=False,
):
    input_file = Path(input_file)
    result_folder = Path(result_folder)
    input_bytecode_file = Path(input_bytecode_file)

    try:
        print(f"Processing file: {input_file}", flush=True)
        bytecode = read_input_bytecode(input_file)
        input_bytecode_file.write_text(bytecode, encoding="utf-8")
        canonical_input_file = PROJECT_DIR / "input_bytecode"
        if input_bytecode_file != canonical_input_file.resolve():
            canonical_input_file.write_text(bytecode, encoding="utf-8")

        function_list, time_consumption, hint_list, function_count = (
            FunctionRestorer().get_results_in_list()
        )

        final_file = result_folder / f"{input_file.stem}_functions.txt"
        with tempfile.TemporaryDirectory(
            prefix="refun_batch_"
        ) as temporary_directory:
            intermediate_file = (
                Path(temporary_directory) / "intermediate_result.txt"
            )
            write_intermediate_result(
                intermediate_file,
                function_list,
                time_consumption,
                hint_list,
                function_count,
            )
            final_summary = generate_final_output(
                intermediate_file,
                final_file,
                source_name=input_file.name,
            )

        legacy_intermediate_file = (
            result_folder / f"{input_file.stem}_result.txt"
        )
        if legacy_intermediate_file.is_file():
            legacy_intermediate_file.unlink()

        if delete_input:
            input_file.unlink()

        print(f"Final result: {final_file}", flush=True)
        return {
            "status": "success",
            "input_file": str(input_file),
            "final_file": str(final_file),
            "public_function_count": final_summary["public_function_count"],
            "private_function_count": final_summary["private_function_count"],
        }
    except Exception as error:
        print(f"Error while processing {input_file}: {error}", flush=True)
        return {
            "status": "error",
            "input_file": str(input_file),
            "error": str(error),
        }


def batch_process(
    input_folder,
    result_folder,
    input_bytecode_file,
    delete_inputs=False,
    progress_callback=None,
):
    input_folder = Path(input_folder).resolve()
    result_folder = Path(result_folder).resolve()
    input_bytecode_file = Path(input_bytecode_file).resolve()

    if not input_folder.is_dir():
        raise NotADirectoryError(f"Input folder not found: {input_folder}")

    result_folder.mkdir(parents=True, exist_ok=True)
    candidate_files = sorted(
        path
        for path in input_folder.iterdir()
        if path.is_file() and path.resolve() != input_bytecode_file
    )
    files = []
    for candidate_file in candidate_files:
        try:
            read_input_bytecode(candidate_file)
            files.append(candidate_file)
        except (OSError, ValueError):
            print(
                f"[SKIP] No bytecode found in {candidate_file.name}",
                flush=True,
            )
    total = len(files)
    results = []

    for index, input_file in enumerate(files, start=1):
        result = process_file(
            input_file,
            result_folder,
            input_bytecode_file,
            delete_input=delete_inputs,
        )
        results.append(result)

        if progress_callback is not None:
            progress_callback(index, total, input_file, result)

        print(
            f"[PROGRESS] {index}/{total} {result['status']} {input_file.name}",
            flush=True,
        )
        if result["status"] == "success":
            print(f"[RESULT] {result['final_file']}", flush=True)

    success_count = sum(result["status"] == "success" for result in results)
    error_count = total - success_count
    print(
        f"[COMPLETE] total={total} success={success_count} error={error_count}",
        flush=True,
    )
    statistics, statistics_file = write_statistics(result_folder)
    print(f"[STATISTICS] {statistics_file}", flush=True)
    extraction_precision = statistics[
        "function_extraction_precision_percent"
    ]
    extraction_precision_text = (
        f"{extraction_precision:.2f}%"
        if extraction_precision is not None
        else "N/A"
    )
    print(
        "[SUMMARY] "
        f"extracted={statistics['extracted_function_count']} "
        "correctly_extracted="
        f"{statistics['correctly_extracted_function_count']} "
        f"extraction_precision={extraction_precision_text} "
        f"average_seconds={statistics['average_time_seconds']:.2f}",
        flush=True,
    )
    return results


def main(argv=None):
    parser = argparse.ArgumentParser(description="Run ReFun on a folder")
    parser.add_argument(
        "--input-folder",
        default=str(PROJECT_DIR / "inputs(wild contracts)"),
    )
    parser.add_argument(
        "--output-folder",
        default=str(PROJECT_DIR / "outputs(extracted functions)"),
    )
    parser.add_argument(
        "--input-bytecode-file",
        default=str(PROJECT_DIR / "input_bytecode"),
    )
    parser.add_argument(
        "--delete-inputs",
        action="store_true",
        help="Delete each source file after it is processed successfully",
    )
    arguments = parser.parse_args(argv)

    original_working_directory = Path.cwd()
    try:
        os.chdir(PROJECT_DIR)
        results = batch_process(
            arguments.input_folder,
            arguments.output_folder,
            arguments.input_bytecode_file,
            delete_inputs=arguments.delete_inputs,
        )
    finally:
        os.chdir(original_working_directory)
    return 0 if all(result["status"] == "success" for result in results) else 1


if __name__ == "__main__":
    sys.exit(main())
