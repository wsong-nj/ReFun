
import subprocess
import sys
import time
from pathlib import Path
from multiple_called_function_recover import MultipleCalledFunctionRecover
from single_called_function_recover import SingleCalledFunctionRecover


class FunctionRestorer(object):
      def __init__(self):
          self.start_time = time.time()
          project_dir = Path(__file__).resolve().parent
          subprocess.run(
              [sys.executable, str(project_dir / 'disassembler.py')],
              cwd=project_dir,
              check=True,
          )


    


      def get_results_in_list(self):
          results = []
          mul_fun = MultipleCalledFunctionRecover().get_functions()
          
          sig_fun, hint_list, sig_fun_counter = SingleCalledFunctionRecover().analyze_hints()
          self.end_time = time.time()
          elapsed_time = self.end_time - self.start_time
          t = f"Elapsed time: {elapsed_time:.2f} seconds"
          for key, value in sig_fun.items():
              for function in value:
                  results.append(function[0])
                  results.append(function[-1])
          for item in mul_fun[1]:
              results.append(item[0])
              results.append(item[-1])
          for key in mul_fun[0].keys():
              results.append(key)
            
                  

                  
          return results, t, hint_list, mul_fun[2]+mul_fun[3]+sig_fun_counter
      









